//! Fixed synthetic diagnostic only; normal library builds do not include it.
use super::*;
use crate::run::{RunOptions, RunReader, write_run};
use crate::{NewRecord, Options, Store};
use std::os::unix::fs::PermissionsExt;
use std::path::Path;
use std::time::Instant;

const FRAMES: usize = 32;
const PER_FRAME: usize = 4;
const ROWS: usize = FRAMES * PER_FRAME;
const ROW_BYTES: usize = 128 << 10;
const BUDGET: usize = 1 << 20;

fn text(id: usize) -> Vec<u8> {
    let mut out = format!("fixed row {id}: \0 日本 ✓\n").into_bytes();
    out.resize(ROW_BYTES, b'a' + (id % 7) as u8);
    out
}
fn key(id: usize) -> Vec<u8> {
    format!("key-{id}").into_bytes()
}
fn attrs(id: usize) -> Vec<u8> {
    format!("attrs-{id}: \0 ✓").into_bytes()
}
fn settings() -> Options {
    Options {
        hot_level: 3,
        dict_bytes: 0,
        dict_train_after: usize::MAX,
        cache_bytes: BUDGET,
        sync: true,
        require_sealed: true,
        cipher: Some(Arc::new(crate::crypto::FrameCipher::new(&[91; 32]))),
        ..Options::default()
    }
}
fn shape(fs: &impl Frames, sealed: bool) {
    assert_eq!(fs.frame_index((ROWS - 1) as u64).unwrap(), FRAMES - 1);
    for i in 0..FRAMES {
        let loc = fs.loc(i);
        assert_eq!(loc.first_seq, (i * PER_FRAME) as u64);
        assert_eq!(loc.count as usize, PER_FRAME);
        let head = get_head(&read_payload(fs.file(loc.file), &loc).unwrap()).unwrap();
        assert_eq!(head.codec, CODEC_ZSTD);
        assert_eq!(head.dict, 0);
        assert_eq!(head.encrypted, sealed);
    }
}
fn hash_record(
    h: &mut blake3::Hasher,
    id: u64,
    kind: u8,
    valid: i64,
    known: i64,
    key: &[u8],
    attrs: &[u8],
    text: &[u8],
) {
    h.update(&id.to_le_bytes());
    h.update(&[kind]);
    h.update(&valid.to_le_bytes());
    h.update(&known.to_le_bytes());
    for bytes in [key, attrs, text] {
        h.update(&(bytes.len() as u64).to_le_bytes());
        h.update(bytes);
    }
}
fn expected(store: bool) -> String {
    let mut h = blake3::Hasher::new();
    for id in 0..ROWS {
        if store {
            hash_record(
                &mut h,
                id as u64,
                (id % 5) as u8,
                id as i64 - 64,
                id as i64 + 269,
                &key(id),
                &attrs(id),
                &text(id),
            );
        } else {
            h.update(&text(id));
        }
    }
    h.finalize().to_hex().to_string()
}
fn prepare(dir: &Path) {
    let mut store = Store::open(&dir.join("store"), settings()).unwrap();
    for frame in 0..FRAMES {
        let ids = frame * PER_FRAME..(frame + 1) * PER_FRAME;
        let texts: Vec<_> = ids.clone().map(text).collect();
        let keys: Vec<_> = ids.clone().map(key).collect();
        let attributes: Vec<_> = ids.clone().map(attrs).collect();
        let records: Vec<_> = ids
            .enumerate()
            .map(|(offset, id)| NewRecord {
                kind: (id % 5) as u8,
                valid_at: id as i64 - 64,
                recorded_at: id as i64 + 269,
                key: &keys[offset],
                attrs: &attributes[offset],
                text: &texts[offset],
            })
            .collect();
        assert_eq!(store.append(&records).unwrap(), (frame * PER_FRAME) as u64);
    }
    shape(&store, true);
    drop(store);
    let options = RunOptions {
        level: 3,
        frame_bytes: PER_FRAME * ROW_BYTES,
        dict_bytes: 0,
        dedupe_chunk: 0,
        threads: 1,
        ..RunOptions::default()
    };
    write_run(&dir.join("rows.run"), &mut (0..ROWS).map(text), &options).unwrap();
    let run = RunReader::open(&dir.join("rows.run"), BUDGET).unwrap();
    shape(&run, false);
    println!(
        "OOJURO_CACHE_TEMPLATE {{\"rows\":{ROWS},\"row_bytes\":{ROW_BYTES},\"frames\":{FRAMES},\"rows_per_frame\":{PER_FRAME},\"cache_budget\":{BUDGET},\"store_originals\":\"{}\",\"run_originals\":\"{}\"}}",
        expected(true),
        expected(false)
    );
}
fn memory(name: &str) -> usize {
    let status = std::fs::read_to_string("/proc/self/status").unwrap();
    let line = status.lines().find(|l| l.starts_with(name)).unwrap();
    line.split_whitespace().nth(1).unwrap().parse().unwrap()
}
struct Phase {
    name: &'static str,
    seconds: f64,
    rss_kib: usize,
    cumulative_hwm_kib: usize,
    entries: usize,
    body_capacity: usize,
    meta_capacity: usize,
    struct_bytes: usize,
    charged: usize,
    hash: String,
}
impl Phase {
    fn json(&self) -> String {
        format!(
            "{{\"name\":\"{}\",\"seconds\":{},\"rss_kib\":{},\"cumulative_hwm_kib\":{},\"entries\":{},\"body_capacity_bytes\":{},\"meta_capacity_bytes\":{},\"decoded_struct_bytes\":{},\"charged_cache_bytes\":{},\"hash\":\"{}\"}}",
            self.name,
            self.seconds,
            self.rss_kib,
            self.cumulative_hwm_kib,
            self.entries,
            self.body_capacity,
            self.meta_capacity,
            self.struct_bytes,
            self.charged,
            self.hash
        )
    }
}
fn phase(fs: &impl Frames, name: &'static str, start: Instant, hash: String) -> Phase {
    let seconds = start.elapsed().as_secs_f64();
    let rss_kib = memory("VmRSS:");
    let cumulative_hwm_kib = memory("VmHWM:");
    let state = fs.read_state().ctx.lock().unwrap();
    fn allocated<T>(v: &Vec<T>) -> usize {
        v.capacity() * std::mem::size_of::<T>()
    }
    let body_capacity = state.cache.values().map(|d| d.body.capacity()).sum();
    let meta_capacity = state
        .cache
        .values()
        .map(|d| {
            allocated(&d.meta.records)
                + allocated(&d.meta.side)
                + allocated(&d.meta.text_start)
                + allocated(&d.meta.pieces)
                + allocated(&d.meta.piece_list)
        })
        .sum();
    Phase {
        name,
        seconds,
        rss_kib,
        cumulative_hwm_kib,
        entries: state.cache.len(),
        body_capacity,
        meta_capacity,
        struct_bytes: state.cache.len() * std::mem::size_of::<Decoded>(),
        charged: state.cached_bytes,
        hash,
    }
}
fn prefixes(fs: &impl Frames, get: &dyn Fn(u64, usize) -> Vec<u8>, phases: &mut Vec<Phase>) {
    for (name, bytes) in [("prefix", 64), ("early_row", ROW_BYTES)] {
        let start = Instant::now();
        let mut hash = blake3::Hasher::new();
        for frame in 0..FRAMES {
            hash.update(&get((frame * PER_FRAME) as u64, bytes));
        }
        let digest = hash.finalize().to_hex().to_string();
        phases.push(phase(fs, name, start, digest.clone()));
    }
    // Oracle construction is outside both timed read stages.
    for (name, bytes) in [("prefix", 64), ("early_row", ROW_BYTES)] {
        let mut expected = blake3::Hasher::new();
        for frame in 0..FRAMES {
            expected.update(&text(frame * PER_FRAME)[..bytes]);
        }
        assert_eq!(
            phases.iter().find(|p| p.name == name).unwrap().hash,
            expected.finalize().to_hex().to_string()
        );
    }
}
fn scan_store(store: &Store, verify: bool) -> String {
    let mut hash = blake3::Hasher::new();
    let mut count = 0;
    store
        .scan_time(i64::MIN, i64::MAX, |r| {
            let id = count;
            assert_eq!(r.seq, id as u64);
            count += 1;
            if verify {
                assert_eq!(
                    (r.kind, r.valid_at, r.recorded_at),
                    ((id % 5) as u8, id as i64 - 64, id as i64 + 269)
                );
                assert_eq!(r.key, key(id));
                assert_eq!(r.attrs, attrs(id));
                assert_eq!(r.text, text(id));
            }
            hash_record(
                &mut hash,
                r.seq,
                r.kind,
                r.valid_at,
                r.recorded_at,
                &r.key,
                &r.attrs,
                &r.text,
            );
            true
        })
        .unwrap();
    assert_eq!(count, ROWS);
    hash.finalize().to_hex().to_string()
}
fn scan_run(run: &RunReader, verify: bool) -> String {
    let mut hash = blake3::Hasher::new();
    let mut count = 0;
    run.scan(0, ROWS as u64, &mut |id, bytes| {
        assert_eq!(id, count as u64);
        count += 1;
        if verify {
            assert_eq!(bytes, text(id as usize));
        }
        hash.update(bytes);
        Ok(())
    })
    .unwrap();
    assert_eq!(count, ROWS);
    hash.finalize().to_hex().to_string()
}

#[test]
#[ignore = "fixed synthetic cache diagnostic; reviewed owned controller only"]
fn fixed_store_run_cache_probe() {
    let dir = std::path::PathBuf::from(std::env::var_os("OOJURO_CACHE_PROBE_DIR").unwrap());
    assert!(dir.is_absolute() && dir.starts_with("/var/tmp"));
    assert_eq!(dir.canonicalize().unwrap(), dir);
    let meta = std::fs::symlink_metadata(&dir).unwrap();
    assert!(meta.is_dir());
    assert_eq!(meta.permissions().mode() & 0o777, 0o700);
    let mode = std::env::var("OOJURO_CACHE_PROBE_MODE").unwrap();
    if mode == "prepare" {
        prepare(&dir);
        return;
    }
    assert!(["store-prefix", "store-full", "run-prefix", "run-full"].contains(&mode.as_str()));
    let mut phases = Vec::new();
    let start = Instant::now();
    let originals;
    if mode.starts_with("store-") {
        let store = Store::open(&dir.join("store"), settings()).unwrap();
        phases.push(phase(&store, "open", start, String::new()));
        shape(&store, true);
        if mode == "store-prefix" {
            prefixes(
                &store,
                &|id, bytes| {
                    if bytes == ROW_BYTES {
                        store.get(id).unwrap()
                    } else {
                        store.get_range(id, 0, bytes).unwrap()
                    }
                },
                &mut phases,
            );
        } else {
            let start = Instant::now();
            let hash = scan_store(&store, false);
            phases.push(phase(&store, "full_scan", start, hash));
        }
        originals = scan_store(&store, true);
        assert_eq!(originals, expected(true));
    } else {
        let run = RunReader::open(&dir.join("rows.run"), BUDGET).unwrap();
        phases.push(phase(&run, "open", start, String::new()));
        shape(&run, false);
        if mode == "run-prefix" {
            prefixes(
                &run,
                &|id, bytes| {
                    if bytes == ROW_BYTES {
                        run.get(id).unwrap()
                    } else {
                        run.get_range(id, 0, bytes).unwrap()
                    }
                },
                &mut phases,
            );
        } else {
            let start = Instant::now();
            let hash = scan_run(&run, false);
            phases.push(phase(&run, "full_scan", start, hash));
        }
        originals = scan_run(&run, true);
        assert_eq!(originals, expected(false));
    }
    println!(
        "OOJURO_CACHE_REPORT {{\"mode\":\"{mode}\",\"rows\":{ROWS},\"row_bytes\":{ROW_BYTES},\"frames\":{FRAMES},\"rows_per_frame\":{PER_FRAME},\"cache_budget\":{BUDGET},\"originals\":\"{originals}\",\"phases\":[{}]}}",
        phases.iter().map(Phase::json).collect::<Vec<_>>().join(",")
    );
}
