#!/usr/bin/python3 -I
"""One optimized Store build, exactly three focused checks and measurement selector listing; no diagnostic workload."""
import argparse, hashlib, json, os, pathlib, re, resource, shutil, signal, subprocess, tempfile, time
W = pathlib.Path(__file__).resolve().parents[3]
OUT = pathlib.Path(__file__).resolve().parent
TOOLS = W / "work/public-ci-rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin"
SOURCES = {'after': ('oojuro-store-cache-full-measure-after', 'b5ede496b6c5e663a0eb8c90f405f432a98c98ce')}
SELECTORS_SHA = "18d6b8944b121731fd6c506a7c2a6db79509a7260622efce6fe89d7650806457"
def sha(p):
    with pathlib.Path(p).open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
def main():
    label=argparse.ArgumentParser();label.add_argument("label",choices=SOURCES);a=label.parse_args()
    tree,commit=SOURCES[a.label];root=W/"work"/tree;out=OUT/a.label
    out.mkdir(mode=0o700) # never overwrite an uncertain prior attempt
    cgtext=pathlib.Path("/proc/self/cgroup").read_text().strip()
    cg=pathlib.Path("/sys/fs/cgroup")/cgtext.split("0::",1)[1].lstrip("/")
    # Preserve raw actual properties before asserting any observed cap.
    observed=subprocess.run(["/usr/bin/systemctl","--user","show",cg.name,"--property=ActiveState","--property=InvocationID","--property=ControlGroup","--property=MainPID","--property=MemoryMax","--property=MemorySwapMax","--property=TasksMax","--property=RuntimeMaxUSec","--property=TimeoutStopUSec","--property=KillMode","--property=LimitCORE"],capture_output=True,text=True,timeout=5)
    (out/"live-properties.json").write_text(json.dumps({"returncode":observed.returncode,"stdout":observed.stdout,"stderr":observed.stderr,"pid":os.getpid(),"cgroup":str(cg)},indent=2)+"\n")
    assert observed.returncode==0
    assert re.fullmatch(r"0::/user.slice/user-1000.slice/user@1000.service/app.slice/oojuro-store-full-read-build-"+a.label+r"-[0-9a-f]{16}\.service",cgtext)
    fields=dict(line.split("=",1) for line in observed.stdout.splitlines() if "=" in line)
    assert fields["ActiveState"]=="active" and fields["MainPID"]==str(os.getpid())
    assert fields["ControlGroup"]==cgtext.split("0::",1)[1]
    assert re.fullmatch("[0-9a-f]{32}",fields["InvocationID"])
    assert all(fields[k]==v for k,v in {"MemoryMax":str(6<<30),"MemorySwapMax":"0","TasksMax":"512","RuntimeMaxUSec":"10min","TimeoutStopUSec":"5s","KillMode":"control-group","LimitCORE":"0"}.items())
    assert set((cg/"cgroup.procs").read_text().split())=={str(os.getpid())}
    assert (cg/"memory.max").read_text().strip()==str(6<<30)
    assert (cg/"pids.max").read_text().strip()=="512"
    assert (cg/"memory.swap.max").read_text().strip()=="0"
    assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip()==commit
    assert not subprocess.check_output(["git","status","--porcelain"],cwd=root,text=True)
    target=W/"work/native-record-borrowed-text-20261024/target-candidate";assert target.is_dir() # C-owned dependency cache; changed source artifacts must rebuild
    assert sha(OUT/"selected-tests.json")==SELECTORS_SHA
    selection=json.loads((OUT/"selected-tests.json").read_text());assert selection["list_selector"]=="reader::cache_probe::fixed_store_run_cache_probe"
    assert len(selection["checks"])==3 and all(c["expected"]==1 for c in selection["checks"])
    assert sha(root/"crates/oojuro-store/src/reader/cache_probe.rs")=="67424be4d2c9928d97094d2a4b77ced91af29598def0f0b09cb7093f2ec05557"
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    scratch=pathlib.Path(tempfile.mkdtemp(prefix="ojcachebuild-",dir="/var/tmp"));scratch.chmod(0o700)
    env=os.environ.copy()
    for key in list(env):
        if key.startswith(("CARGO_PROFILE_","CARGO_TARGET_")) or key in ["CARGO_ENCODED_RUSTFLAGS","RUSTC_WRAPPER","RUSTC_WORKSPACE_WRAPPER","RUSTC_BOOTSTRAP","RUSTUP_TOOLCHAIN","RUSTUP_HOME","CARGO_BUILD_TARGET"]:
            env.pop(key,None)
    env.update(PATH=str(TOOLS)+":"+str(W/"work/portable-key-build")+":<HOME>/.cargo/bin:"+env["PATH"],
               RUSTC=str(TOOLS/"rustc"),RUSTDOC=str(TOOLS/"rustdoc"),CC=str(W/"work/portable-key-build/cc"),
               CXX=str(W/"work/portable-key-build/c++"),CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER=str(W/"work/portable-key-build/cc"),
               RUSTFLAGS="-C target-cpu=x86-64",CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS="2",CARGO_NET_OFFLINE="true",
               CARGO_TERM_COLOR="never",LC_ALL="C",TMPDIR=str(scratch),AWS_EC2_METADATA_DISABLED="true")
    command=[str(TOOLS/"cargo"),"build","--offline","--locked","--target","x86_64-unknown-linux-gnu","-j","2",
             "--release","-p","oojuro-store","--lib","--no-default-features","--message-format=json-render-diagnostics"]
    receipt={"status":"started","phase":"store-lib-build","source":commit,"worktree":str(root),"label":a.label,"command":command,"profile":"release-opt3",
             "target":"x86_64-unknown-linux-gnu","requested_features":[],"cgroup":str(cg),"cgroup_text":cgtext,
             "runtime_seconds":600,"memory_bytes":6<<30,"tasks":512,"core_limit":0,"scratch":str(scratch),
             "environment":{k:env[k] for k in ["RUSTC","RUSTDOC","CC","CXX","RUSTFLAGS","CARGO_TARGET_DIR","CARGO_BUILD_JOBS","CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER"]},
             "lock_sha256":sha(root/"Cargo.lock"),"driver_sha256":sha(__file__),"base_runtime":"d49243820a00424c5ff45042a25d38f6c3753bb5","common_helper_sha256":"67424be4d2c9928d97094d2a4b77ced91af29598def0f0b09cb7093f2ec05557","target_reuse":"C-owned dependency cache only; changed Store lib/libtest/integration artifacts all require fresh:false"}
    def save():
        path=out/"receipt.json";tmp=path.with_name(path.name+".pending")
        fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,"w") as f:json.dump(receipt,f,indent=2);f.write("\n");f.flush();os.fsync(f.fileno())
        os.replace(tmp,path);fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(fd)
        finally:os.close(fd)
    proc=None;code=1;started=time.monotonic()
    try:
        receipt["tools"]={name:{"path":str(TOOLS/name),"sha256":sha(TOOLS/name),
                         "version":subprocess.check_output([str(TOOLS/name),"-vV"],env=env,text=True)} for name in ["cargo","rustc"]}
        assert receipt["tools"]["rustc"]["version"].startswith("rustc 1.99.1 ")
        receipt["wrappers"]={name:sha(W/"work/portable-key-build"/name) for name in ["cc","c++"]}
        baseline=W/"work/store-prefix-cache-capacity-qualification/measurement-build-attempt-1/before/receipt.json"
        prior=json.loads(baseline.read_text())
        assert prior["status"]=="store-cache-measurement-artifact-frozen-listed-no-workload" and prior["source"]=="b66a14bc79b219c4b2f5773a4ab70d422d71b2cc"
        assert prior["libtest"]["sha256"]=="a1e97dae03fe0c9cf68a9aba4fbb4cac29311c5671790e2f92e7565fcac21313" and sha(prior["libtest"]["path"])==prior["libtest"]["sha256"]
        assert all(sha(f["path"])==f["sha256"] for f in prior["normal_store_files"])
        receipt["preserved_baseline"]={"receipt":str(baseline),"sha256":sha(baseline),"libtest_sha256":prior["libtest"]["sha256"]}
        receipt["phase"]="package-only-release-clean"
        clean=[str(TOOLS/"cargo"),"clean","--offline","--locked","--release","--target","x86_64-unknown-linux-gnu","-p","oojuro-store"]
        receipt["clean_command"]=clean;save()
        with (out/"clean.stdout").open("xb") as stdout,(out/"clean.stderr").open("xb") as stderr:
            proc=subprocess.Popen(clean,cwd=root,env=env,stdout=stdout,stderr=stderr);receipt["clean_exit"]=proc.wait(timeout=60)
        save();assert receipt["clean_exit"]==0
        receipt["phase"]="store-lib-build";save()
        with (out/"cargo.jsonl").open("xb") as messages,(out/"cargo.stderr").open("xb") as errors:
            proc=subprocess.Popen(command,cwd=root,env=env,stdout=messages,stderr=errors)
            try:code=proc.wait(timeout=max(1,530-(time.monotonic()-started)))
            except subprocess.TimeoutExpired:receipt["timeout"]=True;raise
        receipt["cargo_exit"]=code;save();assert code==0
        messages=[json.loads(line) for line in (out/"cargo.jsonl").read_text().splitlines() if line.startswith("{")]
        artifacts=[m for m in messages if m.get("reason")=="compiler-artifact"]
        selected=[m for m in artifacts if m["target"]["src_path"]==str(root/"crates/oojuro-store/src/lib.rs")]
        assert len(selected)==1 and selected[0]["fresh"] is False and selected[0]["features"]==[] and selected[0]["profile"]["opt_level"]=="3" and selected[0]["profile"]["test"] is False
        receipt["normal_store_artifact"]=selected[0]
        receipt["normal_store_files"]=[]
        for filename in selected[0]["filenames"]:
            file=pathlib.Path(filename)
            frozen_file=out/("normal-"+file.name);shutil.copyfile(file,frozen_file);frozen_file.chmod(0o400)
            receipt["normal_store_files"].append({"original_path":str(file),"path":str(frozen_file),"bytes":frozen_file.stat().st_size,"sha256":sha(frozen_file)})
        receipt["built_feature_inventory"]=[{"package":m["package_id"],"features":m["features"],"target":m["target"]["name"]} for m in artifacts]
        assert not any("aws-" in m["package_id"] or "aws_" in m["package_id"] or "tantivy" in m["package_id"] or "postgres" in m["package_id"] for m in artifacts)
        treecmd=[str(TOOLS/"cargo"),"tree","--offline","--locked","--target","x86_64-unknown-linux-gnu","-p","oojuro-store","--no-default-features","-e","features"]
        with (out/"features.txt").open("xb") as f:subprocess.run(treecmd,cwd=root,env=env,stdout=f,stderr=subprocess.PIPE,check=True,timeout=30)
        command=[str(TOOLS/"cargo"),"test","--offline","--locked","--release","--target","x86_64-unknown-linux-gnu","-j","2","-p","oojuro-store","--no-default-features","--lib","--no-run","--message-format=json-render-diagnostics"]
        receipt["phase"]="libtest-build";receipt["libtest_command"]=command;save()
        remaining=530-(time.monotonic()-started);assert remaining>0
        with (out/"libtest.jsonl").open("xb") as stdout,(out/"libtest.stderr").open("xb") as stderr:
            proc=subprocess.Popen(command,cwd=root,env=env,stdout=stdout,stderr=stderr)
            receipt["libtest_cargo_exit"]=proc.wait(timeout=remaining)
        save();assert receipt["libtest_cargo_exit"]==0
        messages=[json.loads(line) for line in (out/"libtest.jsonl").read_text().splitlines() if line.startswith("{")]
        tests=[m for m in messages if m.get("reason")=="compiler-artifact" and m["target"]["src_path"]==str(root/"crates/oojuro-store/src/lib.rs") and m["profile"]["test"] is True and m.get("executable")]
        assert len(tests)==1 and tests[0]["fresh"] is False and tests[0]["features"]==[] and tests[0]["profile"]["opt_level"]=="3"
        frozen=out/"oojuro-store-libtest";shutil.copyfile(tests[0]["executable"],frozen);frozen.chmod(0o500)
        header=subprocess.check_output(["readelf","-h",str(frozen)],text=True);assert "Advanced Micro Devices X86-64" in header
        versions=subprocess.check_output(["readelf","--version-info",str(frozen)],text=True)
        glibc=sorted(set(re.findall(r"GLIBC_([0-9.]+)",versions)),key=lambda v:tuple(map(int,v.split("."))))
        assert glibc and tuple(map(int,glibc[-1].split(".")))<=(2,39)
        receipt["libtest"]={"artifact":tests[0],"path":str(frozen),"sha256":sha(frozen),"bytes":frozen.stat().st_size,"source":commit,"glibc_versions":glibc,"readelf_header":header}
        receipt["phase"]="list-only";save()
        command=[str(frozen),"reader::cache_probe::fixed_store_run_cache_probe","--exact","--ignored","--list"]
        with (out/"list.stdout").open("xb") as stdout,(out/"list.stderr").open("xb") as stderr:
            proc=subprocess.Popen(command,cwd=root,env=env,stdout=stdout,stderr=stderr);receipt["list_exit"]=proc.wait(timeout=5)
        receipt["list_command"]=command;receipt["list_stdout"]=(out/"list.stdout").read_text();save()
        assert receipt["list_exit"]==0 and receipt["list_stdout"].splitlines()==["reader::cache_probe::fixed_store_run_cache_probe: test","","1 test, 0 benchmarks"]
        receipt["tests"]=[];receipt["integration_binaries"]={}
        for check in selection["checks"]:
            receipt["phase"]="selector:"+check["name"]
            command=[str(TOOLS/"cargo"),"test","--offline","--locked","--release","--target","x86_64-unknown-linux-gnu","-j","2","-p","oojuro-store","--no-default-features","--message-format=json-render-diagnostics"]
            command += ["--lib"] if check["target"]=="lib" else ["--test",check["target"]]
            command += [check["selector"],"--","--exact","--test-threads=1"]
            item={"name":check["name"],"command":command};receipt["tests"].append(item);save()
            remaining=530-(time.monotonic()-started);assert remaining>0
            with (out/(check["name"]+".stdout")).open("xb") as stdout,(out/(check["name"]+".stderr")).open("xb") as stderr:
                proc=subprocess.Popen(command,cwd=root,env=env,stdout=stdout,stderr=stderr);item["exit"]=proc.wait(timeout=min(180,remaining))
            raw=(out/(check["name"]+".stdout")).read_text()
            item["counts"]=re.findall(r"test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;",raw)
            save();assert item["exit"]==0 and item["counts"]==[("ok","1","0","0")]
            messages=[json.loads(line) for line in raw.splitlines() if line.startswith("{")]
            selected_source=root/("crates/oojuro-store/src/lib.rs" if check["target"]=="lib" else "crates/oojuro-store/tests/"+check["target"]+".rs")
            artifacts=[m for m in messages if m.get("reason")=="compiler-artifact" and m["target"]["src_path"]==str(selected_source) and m["profile"]["test"] is True and m.get("executable")]
            assert len(artifacts)==1 and artifacts[0]["features"]==[] and artifacts[0]["profile"]["opt_level"]=="3"
            artifact=artifacts[0]
            if check["target"]=="lib":
                assert sha(artifact["executable"])==receipt["libtest"]["sha256"]
                item["binary_sha256"]=receipt["libtest"]["sha256"]
            else:
                assert artifact["fresh"] is False
                frozen_test=out/("oojuro-store-"+check["target"]);shutil.copyfile(artifact["executable"],frozen_test);frozen_test.chmod(0o500)
                item["binary_sha256"]=sha(frozen_test)
                receipt["integration_binaries"][check["target"]]={"artifact":artifact,"path":str(frozen_test),"sha256":sha(frozen_test),"bytes":frozen_test.stat().st_size}
            save()
        assert len(receipt["tests"])==3 and set(receipt["integration_binaries"])=={"run","encrypted"}
        receipt["tests_executed"]=3;receipt["workloads_executed"]=0
        receipt["final_worktree_status"]=subprocess.check_output(["git","status","--porcelain"],cwd=root,text=True,timeout=5)
        assert not receipt["final_worktree_status"]
        receipt["final_source"]=subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True,timeout=5).strip()
        assert receipt["final_source"]==commit
        receipt["status"]="store-full-read-artifact-frozen-three-checks-listed-no-diagnostic";receipt["phase"]="terminal";code=0
    except Exception as error:
        tb=error.__traceback__
        while tb.tb_next is not None:tb=tb.tb_next
        receipt["failure_class"]=type(error).__name__;receipt["failure_site"]={"file":pathlib.Path(tb.tb_frame.f_code.co_filename).name,"line":tb.tb_lineno}
        receipt["status"]="build-or-qualification-refused";code=1
    finally:
        # Signal only the still-owned Popen child. Never signal PIDs merely
        # enumerated from cgroup.procs: they may be reaped/reused between reads.
        if proc is not None and proc.poll() is None:
            try:
                proc.kill()
                proc.wait(timeout=5)
            except Exception as error:
                receipt["owned_child_cleanup_error_class"]=type(error).__name__
        remaining={int(p) for p in (cg/"cgroup.procs").read_text().split()}-{os.getpid()}
        receipt["remaining_descendants"]=sorted(remaining)
        receipt["owned_child_reaped"]=proc is None or proc.returncode is not None
        receipt["cleanup_unknown"]=bool(remaining) or not receipt["owned_child_reaped"]
        successful=code==0 and receipt["status"]=="store-full-read-artifact-frozen-three-checks-listed-no-diagnostic"
        if successful and not receipt["cleanup_unknown"]:
            try:shutil.rmtree(scratch)
            except OSError as error:receipt["cleanup_unknown"]=True;receipt["cleanup_error_class"]=type(error).__name__
        receipt["scratch_removed"]=not scratch.exists()
        receipt["scratch_retained_for_failure"]=not successful and not receipt["cleanup_unknown"] and scratch.exists()
        if receipt["cleanup_unknown"] or (successful and not receipt["scratch_removed"]):code=1;receipt["status"]="cleanup-incomplete"
        receipt["wall_seconds"]=round(time.monotonic()-started,3)
        receipt["closed_logs"]={p.name:{"bytes":p.stat().st_size,"sha256":sha(p)} for p in out.iterdir() if p.is_file() and p.name!="receipt.json"}
        save()
    print(json.dumps({"label":a.label,"status":receipt["status"],"receipt":str(out/"receipt.json")}),flush=True)
    return code
if __name__=="__main__":raise SystemExit(main())

