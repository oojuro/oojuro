#!/usr/bin/python3 -I
"""One optimized normal-engine and benchmark build; no tests, server or workload execution."""
import argparse, hashlib, json, os, pathlib, re, resource, shutil, signal, subprocess, tempfile, time
W = pathlib.Path(__file__).resolve().parents[3]
OUT = pathlib.Path(__file__).resolve().parent
TOOLS = W / "work/public-ci-rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin"
SOURCES = {'candidate': ('oojuro-native-current-benchmark-composition', '4a9d99fd2ec9b8eaf8507cad9e33b7d5b98cad4a')}
def sha(p):
    with pathlib.Path(p).open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
def main():
    label=argparse.ArgumentParser();label.add_argument("label",choices=SOURCES);a=label.parse_args()
    tree,commit=SOURCES[a.label];root=W/"work"/tree;out=OUT/a.label
    out.mkdir(mode=0o700) # never overwrite an uncertain prior attempt
    cgtext=pathlib.Path("/proc/self/cgroup").read_text().strip()
    cg=pathlib.Path("/sys/fs/cgroup")/cgtext.split("0::",1)[1].lstrip("/")
    # Preserve raw actual properties before asserting any observed cap.
    observed=subprocess.run(["/usr/bin/systemctl","--user","show",cg.name,"--property=ActiveState","--property=InvocationID","--property=ControlGroup","--property=MainPID","--property=MemoryMax","--property=MemorySwapMax","--property=TasksMax","--property=RuntimeMaxUSec","--property=TimeoutStopUSec","--property=KillMode","--property=LimitCORE"],capture_output=True,text=True,timeout=5)
    (out/"live-properties.json").write_text(json.dumps({"returncode":observed.returncode,"stdout":observed.stdout,"stderr":observed.stderr,"pid":os.getpid(),"cgroup":str(cg)},indent=2)+"\n")
    assert observed.returncode==0
    assert re.fullmatch(r"0::/user.slice/user-1000.slice/user@1000.service/app.slice/oojuro-native-current-bench-build-"+a.label+r"-[0-9a-f]{16}\.service",cgtext)
    fields=dict(line.split("=",1) for line in observed.stdout.splitlines() if "=" in line)
    assert fields["ActiveState"]=="active" and fields["MainPID"]==str(os.getpid())
    assert fields["ControlGroup"]==cgtext.split("0::",1)[1]
    assert re.fullmatch("[0-9a-f]{32}",fields["InvocationID"])
    assert all(fields[k]==v for k,v in {"MemoryMax":str(6<<30),"MemorySwapMax":"0","TasksMax":"512","RuntimeMaxUSec":"20min","TimeoutStopUSec":"5s","KillMode":"control-group","LimitCORE":"0"}.items())
    assert set((cg/"cgroup.procs").read_text().split())=={str(os.getpid())}
    assert (cg/"memory.max").read_text().strip()==str(6<<30)
    assert (cg/"pids.max").read_text().strip()=="512"
    assert (cg/"memory.swap.max").read_text().strip()=="0"
    assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip()==commit
    assert not subprocess.check_output(["git","status","--porcelain"],cwd=root,text=True)
    target=W/"work/native-record-borrowed-text-20261024/target-candidate";assert target.is_dir() # C-owned dependency cache; changed source artifacts must rebuild
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    scratch=pathlib.Path(tempfile.mkdtemp(prefix="ojnativebuild-",dir="/var/tmp"));scratch.chmod(0o700)
    env=os.environ.copy()
    for key in list(env):
        if key.startswith(("CARGO_PROFILE_","CARGO_TARGET_")) or key in ["CARGO_ENCODED_RUSTFLAGS","RUSTC_WRAPPER","RUSTC_WORKSPACE_WRAPPER","RUSTC_BOOTSTRAP","RUSTUP_TOOLCHAIN","RUSTUP_HOME","CARGO_BUILD_TARGET"]:
            env.pop(key,None)
    env.update(PATH=str(TOOLS)+":"+str(W/"work/portable-key-build")+":<HOME>/.cargo/bin:"+env["PATH"],
               RUSTC=str(TOOLS/"rustc"),RUSTDOC=str(TOOLS/"rustdoc"),CC=str(W/"work/portable-key-build/cc"),
               CXX=str(W/"work/portable-key-build/c++"),CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER=str(W/"work/portable-key-build/cc"),
               RUSTFLAGS="-C target-cpu=x86-64",CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS="2",CARGO_NET_OFFLINE="true",
               CARGO_TERM_COLOR="never",LC_ALL="C",TMPDIR=str(scratch),AWS_EC2_METADATA_DISABLED="true")
    command=[str(TOOLS/"cargo"),"build","--offline","--locked","--target","x86_64-unknown-linux-gnu","-j","2",
             "--release","-p","oojuro-engine","--lib","--no-default-features","--message-format=json-render-diagnostics"]
    receipt={"status":"started","phase":"normal-engine-build","source":commit,"worktree":str(root),"label":a.label,"command":command,"profile":"release-opt3",
             "target":"x86_64-unknown-linux-gnu","requested_features":[],"cgroup":str(cg),"cgroup_text":cgtext,
             "runtime_seconds":1200,"memory_bytes":6<<30,"tasks":512,"core_limit":0,"scratch":str(scratch),
             "environment":{k:env[k] for k in ["RUSTC","RUSTDOC","CC","CXX","RUSTFLAGS","CARGO_TARGET_DIR","CARGO_BUILD_JOBS","CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER"]},
             "lock_sha256":sha(root/"Cargo.lock"),"driver_sha256":sha(__file__),"runtime_base":"7dbd7b228a667779c560192a9e8388a709c927e0","benchmark_base":"f4753638c255145e82c48d4f12c87cba3fe78703","target_reuse":"C-owned dependencies reused; six selected workspace packages cleaned for release; normalEngine/Store/rank and benchlib/bin all fresh:false"}
    def save():
        path=out/"receipt.json";tmp=path.with_name(path.name+".pending")
        fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,"w") as f:json.dump(receipt,f,indent=2);f.write("\n");f.flush();os.fsync(f.fileno())
        os.replace(tmp,path);fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(fd)
        finally:os.close(fd)
    proc=None;code=1;started=time.monotonic()
    try:
        receipt["tools"]={name:{"path":str(TOOLS/name),"sha256":sha(TOOLS/name),
                         "version":subprocess.check_output([str(TOOLS/name),"-vV"],env=env,text=True)} for name in ["cargo","rustc"]}
        assert receipt["tools"]["rustc"]["version"].startswith("rustc 1.99.1 ")
        receipt["wrappers"]={name:sha(W/"work/portable-key-build"/name) for name in ["cc","c++"]}
        baseline=W/"work/native-record-streaming-20261024/after/receipt.json"
        prior=json.loads(baseline.read_text())
        assert prior["status"]=="artifact-frozen-two-adapter-tests-passed" and prior["source"]=="ebc9771e8a9d9c018b61bf84743f47e3535b6e01"
        assert prior["binary"]["sha256"]=="5c56be5874a2c56d7d7db5d1d47c1db4ac633de8615ae94442cb3fd1f57c9f87" and sha(prior["binary"]["path"])==prior["binary"]["sha256"]
        assert all(receipt["tools"][name]["sha256"]==prior["tools"][name]["sha256"] for name in ["cargo","rustc"])
        receipt["preserved_baseline"]={"receipt":str(baseline),"sha256":sha(baseline),"binary_sha256":prior["binary"]["sha256"]}
        def tree_at(revision,path):return subprocess.check_output(["git","rev-parse",revision+":"+path],cwd=root,text=True,timeout=5).strip()
        receipt["source_tree_proof"]={}
        for path in ["crates/oojuro-engine","crates/oojuro-store","crates/oojuro-rank"]:
            actual=tree_at(commit,path);assert actual==tree_at(receipt["runtime_base"],path)
            receipt["source_tree_proof"][path]=actual
        for path in ["crates/oojuro-bench","Cargo.lock"]:
            actual=tree_at(commit,path);assert actual==tree_at(receipt["benchmark_base"],path)
            receipt["source_tree_proof"][path]=actual
        receipt["phase"]="package-only-release-clean"
        clean=[str(TOOLS/"cargo"),"clean","--offline","--locked","--release","--target","x86_64-unknown-linux-gnu","-p","oojuro-engine","-p","oojuro-store","-p","oojuro-rank","-p","oojuro-bench","-p","oojuro-core","-p","oojuro-nine"]
        receipt["clean_command"]=clean;save()
        with (out/"clean.stdout").open("xb") as stdout,(out/"clean.stderr").open("xb") as stderr:
            proc=subprocess.Popen(clean,cwd=root,env=env,stdout=stdout,stderr=stderr);receipt["clean_exit"]=proc.wait(timeout=60)
        save();assert receipt["clean_exit"]==0
        receipt["phase"]="normal-engine-build";save()
        with (out/"cargo.jsonl").open("xb") as messages,(out/"cargo.stderr").open("xb") as errors:
            proc=subprocess.Popen(command,cwd=root,env=env,stdout=messages,stderr=errors)
            try:code=proc.wait(timeout=max(1,1130-(time.monotonic()-started)))
            except subprocess.TimeoutExpired:receipt["timeout"]=True;raise
        receipt["cargo_exit"]=code;save();assert code==0
        messages=[json.loads(line) for line in (out/"cargo.jsonl").read_text().splitlines() if line.startswith("{")]
        artifacts=[m for m in messages if m.get("reason")=="compiler-artifact"]
        normal=[];receipt["normal_engine_files"]=[]
        for package in ["oojuro-engine","oojuro-store","oojuro-rank"]:
            selected=[m for m in artifacts if m["target"]["src_path"]==str(root/"crates"/package/"src/lib.rs")]
            assert len(selected)==1 and selected[0]["fresh"] is False and selected[0]["features"]==[] and selected[0]["profile"]["opt_level"]=="3" and selected[0]["profile"]["test"] is False
            normal.append(selected[0])
            for filename in selected[0]["filenames"]:
                file=pathlib.Path(filename);frozen_file=out/("normal-"+package+"-"+file.name)
                shutil.copyfile(file,frozen_file);frozen_file.chmod(0o400)
                receipt["normal_engine_files"].append({"package":package,"original_path":str(file),"path":str(frozen_file),"bytes":frozen_file.stat().st_size,"sha256":sha(frozen_file)})
        receipt["normal_engine_artifacts"]=normal
        receipt["normal_feature_inventory"]=[{"package":m["package_id"],"features":m["features"],"target":m["target"]["name"]} for m in artifacts]
        assert not any("aws-" in m["package_id"] or "aws_" in m["package_id"] or "tantivy" in m["package_id"] or "postgres" in m["package_id"] for m in artifacts)
        treecmd=[str(TOOLS/"cargo"),"tree","--offline","--locked","--target","x86_64-unknown-linux-gnu","-p","oojuro-engine","--no-default-features","-e","features"]
        with (out/"normal-engine-features.txt").open("xb") as f:subprocess.run(treecmd,cwd=root,env=env,stdout=f,stderr=subprocess.PIPE,check=True,timeout=30)
        command=[str(TOOLS/"cargo"),"build","--offline","--locked","--release","--target","x86_64-unknown-linux-gnu","-j","2","-p","oojuro-bench","--bin","oojuro-bench","--no-default-features","--features","sqlite-arm","--message-format=json-render-diagnostics"]
        receipt["phase"]="benchmark-build";receipt["benchmark_command"]=command;save()
        remaining=1130-(time.monotonic()-started);assert remaining>0
        with (out/"bench.jsonl").open("xb") as messages,(out/"bench.stderr").open("xb") as errors:
            proc=subprocess.Popen(command,cwd=root,env=env,stdout=messages,stderr=errors)
            receipt["benchmark_exit"]=proc.wait(timeout=remaining)
        save();assert receipt["benchmark_exit"]==0
        messages=[json.loads(line) for line in (out/"bench.jsonl").read_text().splitlines() if line.startswith("{")]
        artifacts=[m for m in messages if m.get("reason")=="compiler-artifact"]
        selected=[m for m in artifacts if m["target"]["src_path"] in [str(root/"crates/oojuro-bench/src/lib.rs"),str(root/"crates/oojuro-bench/src/main.rs")]]
        assert len(selected)==2 and all(m["fresh"] is False and m["features"]==["sqlite-arm"] and m["profile"]["opt_level"]=="3" and m["profile"]["test"] is False for m in selected)
        engine=[m for m in artifacts if m["target"]["src_path"]==str(root/"crates/oojuro-engine/src/lib.rs")]
        assert len(engine)==1 and engine[0]["features"]==[] and engine[0]["profile"]["opt_level"]=="3" and engine[0]["profile"]["test"] is False
        receipt["benchmark_artifacts"]=selected;receipt["benchmark_engine_artifact"]=engine[0]
        receipt["benchmark_feature_inventory"]=[{"package":m["package_id"],"features":m["features"],"target":m["target"]["name"]} for m in artifacts]
        assert not any("aws-" in m["package_id"] or "aws_" in m["package_id"] or "tantivy" in m["package_id"] or "postgres" in m["package_id"] for m in artifacts)
        binary=next(m for m in selected if m.get("executable"))
        frozen=out/"oojuro-bench";shutil.copyfile(binary["executable"],frozen);frozen.chmod(0o500)
        header=subprocess.check_output(["readelf","-h",str(frozen)],text=True);assert "Advanced Micro Devices X86-64" in header
        versions=subprocess.check_output(["readelf","--version-info",str(frozen)],text=True)
        glibc=sorted(set(re.findall(r"GLIBC_([0-9.]+)",versions)),key=lambda v:tuple(map(int,v.split("."))))
        assert glibc and tuple(map(int,glibc[-1].split(".")))<=(2,39)
        receipt["binary"]={"artifact":binary,"path":str(frozen),"sha256":sha(frozen),"bytes":frozen.stat().st_size,"source":commit,"glibc_versions":glibc,"readelf_header":header,"dynamic_section":subprocess.check_output(["readelf","-d",str(frozen)],text=True)}
        assert all(sha(f["path"])==f["sha256"] for f in receipt["normal_engine_files"])
        assert sha(prior["binary"]["path"])==prior["binary"]["sha256"]
        treecmd=[str(TOOLS/"cargo"),"tree","--offline","--locked","--target","x86_64-unknown-linux-gnu","-p","oojuro-bench","--no-default-features","--features","sqlite-arm","-e","features"]
        with (out/"benchmark-features.txt").open("xb") as f:subprocess.run(treecmd,cwd=root,env=env,stdout=f,stderr=subprocess.PIPE,check=True,timeout=30)
        receipt["tests_executed"]=0;receipt["workloads_executed"]=0
        receipt["final_worktree_status"]=subprocess.check_output(["git","status","--porcelain"],cwd=root,text=True,timeout=5)
        assert not receipt["final_worktree_status"]
        receipt["final_source"]=subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True,timeout=5).strip()
        assert receipt["final_source"]==commit
        receipt["status"]="current-native-engine-benchmark-artifacts-frozen-no-tests-no-workload";receipt["phase"]="terminal";code=0
    except Exception as error:
        tb=error.__traceback__
        while tb.tb_next is not None:tb=tb.tb_next
        receipt["failure_class"]=type(error).__name__;receipt["failure_site"]={"file":pathlib.Path(tb.tb_frame.f_code.co_filename).name,"line":tb.tb_lineno}
        receipt["status"]="build-or-qualification-refused";code=1
    finally:
        # Signal only the still-owned Popen child. Never signal PIDs merely
        # enumerated from cgroup.procs: they may be reaped/reused between reads.
        if proc is not None and proc.poll() is None:
            try:
                proc.kill()
                proc.wait(timeout=5)
            except Exception as error:
                receipt["owned_child_cleanup_error_class"]=type(error).__name__
        remaining={int(p) for p in (cg/"cgroup.procs").read_text().split()}-{os.getpid()}
        receipt["remaining_descendants"]=sorted(remaining)
        receipt["owned_child_reaped"]=proc is None or proc.returncode is not None
        receipt["cleanup_unknown"]=bool(remaining) or not receipt["owned_child_reaped"]
        successful=code==0 and receipt["status"]=="current-native-engine-benchmark-artifacts-frozen-no-tests-no-workload"
        if successful and not receipt["cleanup_unknown"]:
            try:shutil.rmtree(scratch)
            except OSError as error:receipt["cleanup_unknown"]=True;receipt["cleanup_error_class"]=type(error).__name__
        receipt["scratch_removed"]=not scratch.exists()
        receipt["scratch_retained_for_failure"]=not successful and not receipt["cleanup_unknown"] and scratch.exists()
        if receipt["cleanup_unknown"] or (successful and not receipt["scratch_removed"]):code=1;receipt["status"]="cleanup-incomplete"
        receipt["wall_seconds"]=round(time.monotonic()-started,3)
        receipt["closed_logs"]={p.name:{"bytes":p.stat().st_size,"sha256":sha(p)} for p in out.iterdir() if p.is_file() and p.name!="receipt.json"}
        save()
    print(json.dumps({"label":a.label,"status":receipt["status"],"receipt":str(out/"receipt.json")}),flush=True)
    return code
if __name__=="__main__":raise SystemExit(main())

