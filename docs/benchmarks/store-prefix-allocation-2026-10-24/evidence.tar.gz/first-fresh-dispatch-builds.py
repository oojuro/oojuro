#!/usr/bin/python3 -I
"""Two reviewed optimized Store diagnostic builds and list-only checks; no execution without --execute."""
import argparse,hashlib,json,os,pathlib,subprocess,time
BASE=pathlib.Path(__file__).resolve().parent

def sha(p):
    with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def ticks(pid):
    try:return pathlib.Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[19]
    except FileNotFoundError:return None

def save(p,v):
    tmp=p.with_name(p.name+'.pending');fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'w') as f:json.dump(v,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    os.replace(tmp,p);fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)

def one(plan,selected):
    unit=selected['unit'];label=selected['label']
    receipt_path=BASE/('build-dispatch-'+label+'.json')
    assert not receipt_path.exists() and not (BASE/label).exists()
    r={'status':'running','phase':'launch','queries':[],'observed':{},'command':selected['command'],'label':label};identity=None;process=None;code=1
    def persist():save(receipt_path,r)
    def query():
        q=subprocess.run(['/usr/bin/systemctl','--user','show',unit,'--property=LoadState','--property=ActiveState','--property=MainPID','--property=InvocationID','--property=ControlGroup','--property=MemoryMax','--property=MemorySwapMax','--property=TasksMax','--property=RuntimeMaxUSec','--property=TimeoutStopUSec','--property=KillMode','--property=LimitCORE'],capture_output=True,text=True,timeout=5)
        r['queries'].append({'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr});persist()
        return dict(s.split('=',1) for s in q.stdout.splitlines() if '=' in s)
    def observe():
        cg=pathlib.Path('/sys/fs/cgroup')/identity['cgroup'].lstrip('/')
        if not cg.exists():return
        for f in cg.rglob('cgroup.procs'):
            for s in f.read_text().split():
                pid=int(s);start=ticks(pid)
                if not start:continue
                try:exe=os.readlink(f'/proc/{pid}/exe')
                except FileNotFoundError:continue
                except PermissionError:exe=None
                r['observed'].setdefault(f'{pid}:{start}',{'pid':pid,'start_ticks':start,'exe':exe,'exe_unreadable':exe is None,'observed_cgroup':str(f.parent)})
        persist()
    try:
        with (BASE/('build-dispatch-'+label+'.stdout')).open('xb') as out,(BASE/('build-dispatch-'+label+'.stderr')).open('xb') as err:
            process=subprocess.Popen(selected['command'],stdout=out,stderr=err);r['wrapper_pid']=process.pid;persist();until=time.monotonic()+10
            while True:
                f=query()
                if f.get('ActiveState')=='active' and f.get('ControlGroup'):
                    identity={'invocation':f['InvocationID'],'cgroup':f['ControlGroup'],'pid':int(f['MainPID'])};identity['start_ticks']=ticks(identity['pid']);r['identity']=identity;persist()
                    assert len(identity['invocation'])==32 and identity['start_ticks'] and identity['cgroup'].endswith('/'+unit)
                    assert all(f[k]==v for k,v in {'MemoryMax':str(6<<30),'MemorySwapMax':'0','TasksMax':'512','RuntimeMaxUSec':'10min','TimeoutStopUSec':'5s','KillMode':'control-group','LimitCORE':'0'}.items());break
                assert process.poll() is None and time.monotonic()<until;time.sleep(.05)
            r['phase']='observe-build';persist();until=time.monotonic()+630
            while process.poll() is None:
                observe();assert time.monotonic()<until;time.sleep(.1)
            code=process.returncode;r['unit_exit']=code;persist()
    except Exception as e:
        tb=e.__traceback__
        while tb.tb_next is not None:tb=tb.tb_next
        r.update(status='observer-or-unit-refused',error_class=type(e).__name__,failure_site={'file':pathlib.Path(tb.tb_frame.f_code.co_filename).name,'line':tb.tb_lineno});persist()
    finally:
        try:
            r['phase']='outside-cleanup';persist()
            f=query()
            if f.get('ActiveState') not in ['inactive',None] and f.get('LoadState')!='not-found':
                assert identity
                for action in [['kill','--signal=KILL','--kill-whom=all',unit],['stop',unit]]:
                    f=query()
                    if f.get('LoadState')=='not-found' or f.get('ActiveState')=='inactive':break
                    assert f['InvocationID']==identity['invocation'] and f['ControlGroup']==identity['cgroup']
                    q=subprocess.run(['/usr/bin/systemctl','--user',*action],capture_output=True,text=True,timeout=10)
                    r.setdefault('termination',[]).append({'action':action,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr});persist()
            if process is not None and process.poll() is None:
                try:process.wait(timeout=10)
                except subprocess.TimeoutExpired:process.kill();process.wait(timeout=5)
            f=query();assert identity and (f.get('LoadState')=='not-found' or f.get('ActiveState')=='inactive')
            cg=pathlib.Path('/sys/fs/cgroup')/identity['cgroup'].lstrip('/');assert not cg.exists()
            r['original_main_absent']=ticks(identity['pid'])!=identity['start_ticks']
            r['all_observed_absent']=all(ticks(v['pid'])!=v['start_ticks'] for v in r['observed'].values())
            manager=pathlib.Path(f'/sys/fs/cgroup/user.slice/user-{os.getuid()}.slice/user@{os.getuid()}.service')
            assert cg.is_relative_to(manager);named=[];count=0;until=time.monotonic()+20
            def fail(error):raise error
            for parent,dirs,files in os.walk(manager,onerror=fail):
                count+=1;assert count<=4096 and time.monotonic()<until
                if unit in dirs:named.append(str(pathlib.Path(parent)/unit))
            r['named_cgroups_remaining']=named;r['actual_cgroup_absent']=True
            r['resource_cleanup_complete']=r['original_main_absent'] and r['all_observed_absent'] and not named
            body_path=BASE/label/'receipt.json'
            if not body_path.exists():
                r.update(worker_status='missing-receipt',cleanup_complete=r['resource_cleanup_complete']);code=1
            else:
                body=json.loads(body_path.read_text())
                r['worker_status']=body['status'];r['worker_failure_class']=body.get('failure_class');r['worker_last_phase']=body.get('tests',[])[-1]['name'] if body.get('tests') else 'store-lib-build'
                scratch=pathlib.Path(body['scratch'])
                r['scratch_absent']=not scratch.exists();r['worker_reported_scratch_removed']=body.get('scratch_removed',False)
                r['cleanup_complete']=r['resource_cleanup_complete'] and r['scratch_absent'] and r['worker_reported_scratch_removed'] and not body.get('cleanup_unknown',False) and not body.get('remaining_descendants',[])
                if not r['cleanup_complete'] or body['status']!='store-cache-measurement-artifact-frozen-listed-no-workload':code=1
        except Exception as e:
            tb=e.__traceback__
            while tb.tb_next is not None:tb=tb.tb_next
            r.update(cleanup_complete=False,cleanup_error_class=type(e).__name__,cleanup_failure_site={'file':pathlib.Path(tb.tb_frame.f_code.co_filename).name,'line':tb.tb_lineno});code=1
        r['exit']=code;r['status']='passed' if code==0 else 'failed-or-incomplete';persist()
    print(json.dumps({'exit':code,'label':label,'receipt':str(receipt_path)}),flush=True);return code

def main():
    p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');a=p.parse_args()
    plan=json.loads((BASE/'build-planned-commands.json').read_text())
    if not a.execute:print(json.dumps(plan,indent=2));return 0
    os.umask(0o077);assert sha(BASE/'build-artifact.py')==plan['driver_sha256']
    assert sha(BASE/'selected-tests.json')==plan['selected_tests_sha256'] and sha(__file__)==plan['dispatcher_sha256']
    assert [s['label'] for s in plan['sequential_units']]==['after']
    for selected in plan['sequential_units']:
        code=one(plan,selected)
        if code:return code
    return 0

if __name__=='__main__':raise SystemExit(main())
