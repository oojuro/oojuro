#!/usr/bin/python3 -I
"""One fixed current-native/borrowed-row SWE comparison, no execution on import."""
import argparse,ast,ctypes,hashlib,json,os,pathlib,re,resource,shutil,stat,subprocess,tempfile,time,traceback
BASE=pathlib.Path(__file__).resolve().parent
W=BASE.parents[2]
ROOT=W/'work/oojuro-native-borrowed-projection-rows'
SOURCE='4c2331fd7c9c16e0eb2e864786a252d59b83cd6b'
NATIVE_SOURCE='4a9d99fd2ec9b8eaf8507cad9e33b7d5b98cad4a'
ARTIFACT=W/'work/native-borrowed-projection-rows-qualification/build-attempt-1/candidate/oojuro-bench'
NATIVE=W/'work/native-current-benchmark-qualification/build-attempt-1/candidate/oojuro-bench'
SHAS={str(ARTIFACT):'bcf133459366fa5d75b44a32f395c72da70fbacff408a610111f66fedb2a55a1',str(NATIVE):'c129bfb3df95c626371486a69f77ade9ab39963f8f5b79aaa2c5306db1635f6b'}
DATA=W/'work/native-benchmark/data'
INPUT_SHA='3106438b52feadab2bcf3c0e7ff7fb40ac8625b3969312e8cf64d4c3782089c2'
REFERENCE=W/'work/native-record-streaming-20261024/run-09dcbe2dc27910b2/pools-round-0.native_after'
REFERENCE_SHA='bb6b2a2cc17e63b924b93021d475706071da35a0843a2ba7b265aab551b66463'
ARMS={'native':[str(NATIVE),'serve','--arm','native-record'],'current':[str(ARTIFACT),'serve','--arm','native-record']}
def sha(p):
    with pathlib.Path(p).open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()

def save(p,value):
    tmp=p.with_name(p.name+".pending")
    fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,"w") as f:json.dump(value,f,indent=2);f.write("\n");f.flush();os.fsync(f.fileno())
    os.replace(tmp,p)
    fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)

def read_json(p):
    assert p.stat().st_size<=8<<20
    return json.loads(p.read_text())

def ticks(pid):
    try:return pathlib.Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[19]
    except FileNotFoundError:return None

def inventory(root):
    rows=[];directory_rows=[];dirs=0;dir_bytes=0;seen=set();device=root.lstat().st_dev
    def walk(p):
        nonlocal dirs,dir_bytes
        m=p.lstat();assert m.st_dev==device and (m.st_dev,m.st_ino) not in seen;seen.add((m.st_dev,m.st_ino))
        assert len(seen)<=32768 and not stat.S_ISLNK(m.st_mode)
        if stat.S_ISDIR(m.st_mode):
            dirs+=1;dir_bytes+=m.st_blocks*512;directory_rows.append({"path":str(p.relative_to(root)),"mode":stat.S_IMODE(m.st_mode),"allocated":m.st_blocks*512})
            for child in sorted(p.iterdir()):walk(child)
        else:
            assert stat.S_ISREG(m.st_mode) and m.st_nlink==1
            rows.append({'path':str(p.relative_to(root)),'mode':stat.S_IMODE(m.st_mode),'bytes':m.st_size,'allocated':m.st_blocks*512,'sha256':sha(p)})
            assert p.stat().st_size==m.st_size
        assert sum(r['bytes'] for r in rows)<=2<<30 and sum(r['allocated'] for r in rows)+dir_bytes<=2<<30
    assert root.is_dir() and not root.is_symlink();walk(root)
    assert rows
    return {'snapshot_complete':True,'files':rows,'directory_entries':directory_rows,'directories':dirs,'apparent_file_bytes':sum(r['bytes'] for r in rows),'allocated_file_bytes':sum(r['allocated'] for r in rows),'allocated_directory_bytes':dir_bytes,'allocated_total_bytes':sum(r['allocated'] for r in rows)+dir_bytes,'scope':'closed pathname blocks including directories; no filesystem-global journal/inode or GC attribution'}

def reconcile(run,harness_pids,manager):
    assert all(type(pid) is int and pid>0 for pid in harness_pids)
    manager=pathlib.Path(manager)
    assert manager==pathlib.Path(f'/sys/fs/cgroup/user.slice/user-{os.getuid()}.slice/user@{os.getuid()}.service')
    end=time.monotonic()+100;rows=[];unknown=[]
    def issue(phase,error):unknown.append({'phase':phase,'class':type(error).__name__})
    try:lines=(run/'scopes.jsonl').read_text().splitlines()
    except Exception as error:issue('inventory',error);lines=[]
    if len(lines)>16:issue('inventory-bound',ValueError());lines=lines[:16]
    identities={};observed={}
    for name,target in [('scope-identities.json',identities),('scope-observations.json',observed)]:
        try:
            if (run/name).exists():target.update(read_json(run/name))
        except Exception as error:issue(name,error)
    def path(unit,value):
        assert isinstance(value,str) and value.startswith('/') and '..' not in pathlib.PurePosixPath(value).parts
        p=pathlib.Path('/sys/fs/cgroup')/value.lstrip('/')
        assert p.is_relative_to(manager) and p.name==unit
        return p
    for line in lines:
        item={'queries':[]};rows.append(item)
        try:
            record=json.loads(line);unit=record['unit'];item['inventory']=record
            assert record['harness_pid'] in harness_pids and re.fullmatch(r'oojuro-arm-(native|current|copynative|copycurrent)-'+str(record['harness_pid'])+r'-[0-9]+\.scope',unit)
            def query():
                left=end-time.monotonic();assert left>0
                args=['/usr/bin/systemctl','--user','show',unit,'--property=LoadState','--property=ActiveState','--property=ControlGroup','--property=InvocationID']
                q=subprocess.run(args,capture_output=True,text=True,timeout=min(5,left))
                item['queries'].append({'command':args,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr})
                save(run/'scope-reconciliation.json',{'rows':rows,'unknown':unknown})
                v=dict(x.split('=',1) for x in q.stdout.splitlines() if '=' in x)
                if v.get('ControlGroup'):
                    actual=v['ControlGroup'];path(unit,actual)
                    if actual not in observed.setdefault(unit,[]):observed[unit].append(actual);save(run/'scope-observations.json',observed)
                return v
            v=query()
            if v.get('ActiveState') in ['active','activating','deactivating','failed']:
                if unit not in identities:
                    assert ticks(record['launcher_pid'])==record['start_ticks']
                    assert pathlib.Path(f"/proc/{record['launcher_pid']}/cgroup").read_text().strip()=='0::'+v['ControlGroup']
                    assert re.fullmatch('[0-9a-f]{32}',v['InvocationID'])
                    identities[unit]={'invocation_id':v['InvocationID'],'control_group':v['ControlGroup']}
                    save(run/'scope-identities.json',identities)
                for action in [['kill','--signal=KILL','--kill-whom=all',unit],['stop',unit]]:
                    v=query();identity=identities[unit]
                    if v.get('LoadState')=='not-found' or v.get('ActiveState')=='inactive':break
                    assert v['InvocationID']==identity['invocation_id'] and v['ControlGroup']==identity['control_group']
                    left=end-time.monotonic();assert left>0
                    q=subprocess.run(['/usr/bin/systemctl','--user',*action],capture_output=True,text=True,timeout=min(5,left))
                    item.setdefault('termination',[]).append({'action':action,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr})
                    save(run/'scope-reconciliation.json',{'rows':rows,'unknown':unknown})
            until=min(end,time.monotonic()+5)
            while True:
                v=query();dead=v.get('LoadState')=='not-found' or v.get('ActiveState')=='inactive'
                actual_absent=all(not path(unit,p).exists() for p in observed.get(unit,[]))
                named=[];count=0
                def failed(error):raise error
                if dead:
                    for parent,dirs,files in os.walk(manager,onerror=failed):
                        count+=1;assert count<=4096 and time.monotonic()<end
                        if unit in dirs:named.append(str(pathlib.Path(parent)/unit))
                if dead and actual_absent and not named and ticks(record['launcher_pid'])!=record['start_ticks']:break
                assert time.monotonic()<until;time.sleep(.05)
            item.update(status='reconciled',actual_paths_absent=actual_absent,exact_named_paths_remaining=named,original_pid_identity_absent=True)
        except Exception as error:item['status']='unknown';issue('scope',error)
    result={'rows':rows,'unknown':unknown,'manager_hierarchy':str(manager)}
    save(run/'scope-reconciliation.json',result);return result

def observe(run,seen):
    lines=(run/'scopes.jsonl').read_text().splitlines();assert len(lines)<=16
    identities=read_json(run/'scope-identities.json') if (run/'scope-identities.json').exists() else {}
    paths=read_json(run/'scope-observations.json') if (run/'scope-observations.json').exists() else {}
    for line in lines:
        record=json.loads(line);unit=record['unit']
        assert re.fullmatch(r'oojuro-arm-(native|current|copynative|copycurrent)-'+str(record['harness_pid'])+r'-[0-9]+\.scope',unit)
        if unit in identities:
            values=identities[unit];cg=pathlib.Path('/sys/fs/cgroup')/values['control_group'].lstrip('/')
        else:
            q=subprocess.run(['/usr/bin/systemctl','--user','show',unit,'--property=ActiveState','--property=ControlGroup','--property=InvocationID','--property=MemoryMax','--property=MemorySwapMax','--property=TasksMax','--property=RuntimeMaxUSec','--property=TimeoutStopUSec'],capture_output=True,text=True,timeout=2)
            raw=read_json(run/'scope-live-raw.json') if (run/'scope-live-raw.json').exists() else []
            assert len(raw)<1000;raw.append({'unit':unit,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr});save(run/'scope-live-raw.json',raw)
            f=dict(x.split('=',1) for x in q.stdout.splitlines() if '=' in x)
            if f.get('ActiveState')!='active' or not f.get('ControlGroup'):continue
            assert re.fullmatch('[0-9a-f]{32}',f['InvocationID']) and f['ControlGroup'].endswith('/'+unit)
            assert all(f[k]==v for k,v in {'MemoryMax':str(3<<30),'MemorySwapMax':'0','TasksMax':'512','RuntimeMaxUSec':'10min','TimeoutStopUSec':'5s'}.items())
            identities[unit]={'invocation_id':f['InvocationID'],'control_group':f['ControlGroup']};save(run/'scope-identities.json',identities)
            paths[unit]=[f['ControlGroup']];save(run/'scope-observations.json',paths)
            cg=pathlib.Path('/sys/fs/cgroup')/f['ControlGroup'].lstrip('/')
        if cg.exists():
            for p in cg.rglob('cgroup.procs'):
                for token in p.read_text().split():
                    pid=int(token);start=ticks(pid)
                    if start is None:continue
                    try:exe=os.readlink(f'/proc/{pid}/exe')
                    except FileNotFoundError:continue
                    except PermissionError:exe=None
                    seen.setdefault(f'{pid}:{start}',{'pid':pid,'start_ticks':start,'exe':exe,'cgroup':str(p.parent)})

def normalized(row):
    assert set(row)<=set(['id','key','text','valid_at','recorded_at','meta'])
    return dict(row,key=row.get('key',''),meta=row.get('meta',{}))

def inventory_equal(a,b):
    # Physical allocation may differ after a byte-exact copy; hashes/modes cannot.
    def content(x):return [{k:v for k,v in row.items() if k!='allocated'} for row in x['files']]
    return [{k:v for k,v in row.items() if k!='allocated'} for row in a['directory_entries']]==[{k:v for k,v in row.items() if k!='allocated'} for row in b['directory_entries']] and content(a)==content(b)

def reap_adopted(receipt,exclude=None):
    # Read actual direct-child ownership, never guessed or globally enumerated PIDs.
    # Excluding the current Popen leader preserves its one authoritative wait.
    values=pathlib.Path(f'/proc/self/task/{os.getpid()}/children').read_text().split()
    assert len(values)<=512
    for value in values:
        pid=int(value)
        if pid==exclude:continue
        start=ticks(pid)
        try:got,status=os.waitpid(pid,os.WNOHANG)
        except ChildProcessError:continue
        if got:receipt.setdefault('adopted_reaped',[]).append({'pid':got,'start_ticks':start,'wait_status':status})

def expected_swe():
    path=W/'work/native-benchmark/verify-cold-stores.py'
    assert sha(path)=='90538e0b5fad4653d996a0416be0c5867074a92f97aab85f5318ac03e60ab0a2'
    names={'doc','trajectory','expected_swe'};nodes=[n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in names];assert {n.name for n in nodes}==names
    env={'base':DATA.parent,'json':json};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),env)
    expected=env['expected_swe'](20000);assert len(expected)==20623 and sum(len(r['text'].encode()) for r in expected.values())==14716773
    return expected

def ranges_for(expected):
    counts={}
    for row in expected.values():counts[row['valid_at']]=counts.get(row['valid_at'],0)+1
    ranges=[];lower=-(1<<63);count=0;previous=None
    for at,size in sorted(counts.items()):
        assert size<=9999
        if count+size>9999:ranges.append({'op':'get_range','from':lower,'to':previous,'limit':10000});lower=previous+1;count=0
        count+=size;previous=at
    ranges.append({'op':'get_range','from':lower,'to':(1<<63)-1,'limit':10000});return ranges

def scope_args(label,binary,arm):
    return [str(BASE/'systemd-run'),'--user','--scope','--quiet','--collect',f'--unit=oojuro-arm-{label}-{os.getpid()}-{time.monotonic_ns()}','--property=MemoryMax=3G','--property=MemorySwapMax=0','--property=TasksMax=512','--property=RuntimeMaxSec=600','--property=TimeoutStopSec=5','--',str(binary),'serve','--arm',arm]

def run_child(argv,label,run,env,receipt,end,stdin=None):
    item={'label':label,'command':argv};receipt['children'].append(item);save(run/'receipt.json',receipt)
    with (run/(label+'.stdout')).open('xb') as out,(run/(label+'.stderr')).open('xb') as err:
        source=stdin.open('rb') if stdin else subprocess.DEVNULL
        try:child=subprocess.Popen(argv,cwd=ROOT,env=env,stdin=source,stdout=out,stderr=err)
        finally:
            if stdin:source.close()
        item.update(pid=child.pid,start_ticks=ticks(child.pid));save(run/'receipt.json',receipt)
        try:
            while child.poll() is None:
                reap_adopted(receipt,exclude=child.pid);observe(run,receipt['observed_descendants'])
                assert time.monotonic()<end and (run/(label+'.stdout')).stat().st_size<=64<<20 and (run/(label+'.stderr')).stat().st_size<=8<<20
                time.sleep(.1)
            item['exit']=child.returncode;save(run/'receipt.json',receipt)
            assert (run/(label+'.stdout')).stat().st_size<=64<<20 and (run/(label+'.stderr')).stat().st_size<=8<<20
            assert child.returncode==0
        finally:
            if child.poll() is None:child.kill();child.wait(timeout=5)
    reap_adopted(receipt);return item

def protocol_child(label,binary,arm,requests,run,env,receipt,end):
    inp=run/(label+'.stdin');inp.write_bytes(b''.join((json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n').encode() for r in requests));inp.chmod(0o600);assert inp.stat().st_size<4<<20
    child=run_child(scope_args(label,binary,arm),label,run,env,receipt,end,inp)
    raw=(run/(label+'.stdout')).read_bytes().split(b'\n');assert raw[-1]==b'';raw.pop();assert len(raw)==len(requests)
    replies=[json.loads(line) for line in raw];assert all(r.get('ok') is True for r in replies)
    assert replies[0]['info']['commit']==(SOURCE if label in ['current','copycurrent'] else NATIVE_SOURCE)[:12]
    return replies,child

def disk_budget(stage):
    total=0;entries=0
    for parent,dirs,files in os.walk(stage):
        for name in [*dirs,*files]:
            m=(pathlib.Path(parent)/name).lstat();assert not stat.S_ISLNK(m.st_mode);entries+=1;total+=m.st_blocks*512
            assert entries<=100000 and total<=4<<30
    return {'allocated_pathname_bytes':total,'entries':entries,'cap_bytes':4<<30}

def command(stage,run,n):
    order=['native','current'] if n%2==0 else ['current','native']
    args=[str(ARTIFACT),'turnloop','--runs','1','--mem-max','3G','--data',str(DATA),'--keep','--set','swe-agent','--split','dev','--trajectories','10','--background','20000','--thinking','index','--k','20','--pool','20','--batch','1000','--work',str(stage/f'w/r{n}'),'--out',str(run/f'round-{n}.json'),'--dump-pools',str(run/f'pools-round-{n}')]
    for label in order:args+=['--arm',label+'=cmd:'+' '.join(ARMS[label])]
    return args

def validate_card(path):
    card=read_json(path);assert card['schema']=='oojuro-scorecard-v1' and card['suite']=='turnloop' and len(card['arms'])==2
    assert {r['label'] for r in card['arms']}=={'native','current'}
    assert all(card['settings'][k]==v for k,v in {'runs':1,'steps':201,'trajectories':10,'background_target_records':20000,'thinking':'index','k':20,'pool':20}.items())
    for r in card['arms']:
        assert not r.get('error') and set(r['gates'])=={'no_future_leak','byte_exact','freshness'} and all(g['pass'] for g in r['gates'].values())
        assert r['info']['commit']==(SOURCE if r['label']=='current' else NATIVE_SOURCE)[:12]
        assert r['speed']['store_records_end']['median']==20623
        for section,key in [('memory','peak_cgroup_bytes'),('speed','returned_original_bytes')]:assert r[section][key]['n']==1 and r[section][key]['median']>0
    for r in card['arms']:
        for key in ['peak_rss_bytes','peak_cgroup_bytes','steady_rss_bytes','steady_cgroup_bytes','steady_anon_bytes','steady_file_bytes']:
            assert r['memory'][key]['n']==1 and r['memory'][key]['median']>=0
    assert card['arms'][0]['quality']==card['arms'][1]['quality']
    assert len({r['speed']['returned_original_bytes']['median'] for r in card['arms']})==1
    return card

def copy_check(source,destination,label,expected,run,env,receipt,end):
    before=inventory(source);save(run/(label+'-source-before.json'),before);shutil.copytree(source,destination,copy_function=shutil.copy2)
    copied=inventory(destination);save(run/(label+'-copy-before.json'),copied);assert inventory_equal(before,copied)
    arm='native-record';binary=ARTIFACT if label.startswith('current') else NATIVE
    ranges=ranges_for(expected);ids=list(expected)
    requests=[{'op':'hello'},{'op':'open','dir':str(destination)},{'op':'stats'},*ranges]
    for at in range(0,len(ids),500):requests.append({'op':'get','ids':ids[at:at+500]})
    requests.extend([{'op':'get','ids':['missing-copy-probe']},{'op':'close'}])
    # The strict scope label is closed; per-round output paths remain separate.
    tag='copycurrent' if label.startswith('current') else 'copynative'
    assert not (run/(tag+'.stdout')).exists()
    replies,child=protocol_child(tag,binary,arm,requests,run,env,receipt,min(end,time.monotonic()+180))
    got=[normalized(row) for response in replies[3:3+len(ranges)] for row in response['docs']]
    assert len(got)==len(expected) and len({r['id'] for r in got})==len(expected)
    assert all(row==expected.get(row['id']) for row in got)
    assert [r['valid_at'] for r in got]==sorted(r['valid_at'] for r in got)
    at=3+len(ranges)
    for start in range(0,len(ids),500):assert replies[at]['texts']==[expected[id]['text'] for id in ids[start:start+500]];at+=1
    assert replies[at]['texts']==[None]
    after=inventory(source);save(run/(label+'-source-after.json'),after);assert before==after
    post=inventory(destination);save(run/(label+'-copy-after.json'),post)
    # Preserve each protocol log/input under a unique round label before next copy.
    for extension in ['stdin','stdout','stderr']:(run/(tag+'.'+extension)).rename(run/(label+'.'+extension))
    result={'label':label,'full_docs':len(got),'all_fields_equal':True,'all_get_originals_equal':True,'source_unchanged':True,'stats':replies[2].get('stats'),'child':child,'inventory':before,'copy_inventory_before':copied,'copy_inventory_after':post}
    receipt['copies'].append(result);save(run/'receipt.json',receipt)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true');a=parser.parse_args();plan=read_json(BASE/'planned-commands.json')
    if not a.execute:print(json.dumps(plan,indent=2));return 0
    os.umask(0o077);resource.setrlimit(resource.RLIMIT_CORE,(0,0));libc=ctypes.CDLL(None,use_errno=True);assert libc.prctl(36,1,0,0,0)==0;sr=ctypes.c_int();assert libc.prctl(37,ctypes.byref(sr),0,0,0)==0 and sr.value==1
    run=pathlib.Path(plan['run']);run.mkdir(mode=0o700);(run/'scopes.jsonl').touch(mode=0o600)
    receipt={'status':'started','sources':{'native':NATIVE_SOURCE,'current':SOURCE},'artifacts':SHAS,'children':[],'records':[],'copies':[],'observed_descendants':{},'scope':'four paired local current-native/borrowed-row SWE rounds; identical logical workload/results/originalbytes required, all memory/tails reported; no hosted/price/OS-cold/largerthanRAM/SOTA claim'};save(run/'receipt.json',receipt)
    start=time.monotonic();work_end=start+1800;verify_end=start+2400;stage=None;code=1
    cgtext=pathlib.Path('/proc/self/cgroup').read_text().strip().split('0::',1)[1];cg=pathlib.Path('/sys/fs/cgroup')/cgtext.lstrip('/');manager=cg.parent.parent
    def harnesses():return [os.getpid(),*[c['pid'] for c in receipt['children'] if c['label'].startswith('round-')]]
    try:
        q=subprocess.run(['/usr/bin/systemctl','--user','show',plan['unit'],'--property=MainPID','--property=InvocationID','--property=ControlGroup','--property=MemoryMax','--property=MemorySwapMax','--property=TasksMax','--property=RuntimeMaxUSec','--property=KillMode','--property=TimeoutStopUSec','--property=LimitCORE'],capture_output=True,text=True,timeout=5)
        receipt['outer_raw']={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr};save(run/'receipt.json',receipt)
        f=dict(x.split('=',1) for x in q.stdout.splitlines() if '=' in x)
        assert f['MainPID']==str(os.getpid()) and f['ControlGroup']==cgtext and cg.name==plan['unit']
        assert all(f[k]==v for k,v in {'MemoryMax':str(6<<30),'MemorySwapMax':'0','TasksMax':'512','RuntimeMaxUSec':'42min','KillMode':'control-group','TimeoutStopUSec':'5s','LimitCORE':'0'}.items())
        assert set((cg/'cgroup.procs').read_text().split())=={str(os.getpid())}
        for p,h in SHAS.items():assert sha(pathlib.Path(p))==h
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True,timeout=5).strip()==SOURCE and not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True,timeout=5)
        assert sha(ROOT/'crates/oojuro-bench/src/turnloop.rs')=='ace03b31d0bb3d210f54fd28cf11e1b1cd748252f35c36ed72269188583fabf6'
        data=DATA/'prepared/turnloop/swe-agent.jsonl';assert data.stat().st_size==695520625 and sha(data)==INPUT_SHA and sha(REFERENCE)==REFERENCE_SHA
        qualified=pathlib.Path(plan['build_qualification']);assert sha(qualified)==plan['build_qualification_sha256']
        proof=read_json(qualified);assert proof['status']=='root-qualified-borrowed-native-engine-benchmark-builds-and-eight-checks' and proof['source']==SOURCE
        assert proof['checks_passed']==8 and any(f['path']==str(ARTIFACT) and f['sha256']==SHAS[str(ARTIFACT)] for f in proof['artifacts'])
        prior=pathlib.Path(plan['baseline_qualification']);assert sha(prior)==plan['baseline_qualification_sha256']
        prior=read_json(prior);assert prior['status']=='root-qualified-current-native-release-engine-and-benchmark-build-only' and prior['source']==NATIVE_SOURCE and prior['binary']['sha256']==SHAS[str(NATIVE)] and prior['tests_and_workloads_executed']==0
        assert shutil.disk_usage('/var/tmp').free>=5<<30
        stage=pathlib.Path(tempfile.mkdtemp(prefix='nbrows-',dir='/var/tmp'));stage.chmod(0o700);receipt['retained_stage']=str(stage);save(run/'receipt.json',receipt)
        save(run/'launcher.json',{'format':1,'driver':str(ARTIFACT),'native':str(NATIVE),'inventory':str(run/'scopes.jsonl'),'controller_pid':os.getpid(),'controller_start_ticks':ticks(os.getpid()),'controller_exe':os.readlink('/proc/self/exe')})
        env=os.environ.copy()
        for key in list(env):
            if key.startswith(('PG','OOJURO_BENCH_POSTGRES_')) or key in ['LD_PRELOAD','LD_LIBRARY_PATH','OOJURO_BENCH_LOCK']:env.pop(key,None)
        env.update(PATH=str(BASE)+':/usr/bin:/bin',LC_ALL='C',TMPDIR=str(stage),OOJURO_NATIVE_COMPARE_CONTROL=str(run/'launcher.json'),AWS_EC2_METADATA_DISABLED='true')
        assert [command(stage,run,n) for n in range(4)]==[[part.replace('{STAGE}',str(stage)) for part in argv] for argv in plan['commands_template']]
        for n in range(4):
            argv=command(stage,run,n);item={'round':n,'command':argv,'order':['native','current'] if n%2==0 else ['current','native']};receipt['records'].append(item);save(run/'receipt.json',receipt)
            run_child(argv,f'round-{n}',run,env,receipt,work_end);card=validate_card(run/f'round-{n}.json');item['card']=card
            for label in ['native','current']:
                raw=(run/f'pools-round-{n}.{label}').read_bytes();pool=[json.loads(x) for x in raw.split(b'\n') if x];assert len(pool)==52
                assert raw==REFERENCE.read_bytes() # all52 saved labelled IDs+scorebits, not all201 ranklists
                item.setdefault('pools',{})[label]={'rows':len(pool),'sha256':hashlib.sha256(raw).hexdigest()}
            receipt['scope_cleanup']=reconcile(run,harnesses(),manager);assert not receipt['scope_cleanup']['unknown'];item['disk_budget']=disk_budget(stage);save(run/'receipt.json',receipt)
        expected=expected_swe()
        for n in range(4):
            for label in ['native','current']:
                assert time.monotonic()<verify_end
                source=stage/f'w/r{n}'/label/'run0-turnloop/store';closed=inventory(source)
                row=next(r for r in receipt['records'][n]['card']['arms'] if r['label']==label)
                assert closed['apparent_file_bytes']==row['storage']['disk_bytes']['median'] and closed['allocated_total_bytes']==row['storage']['disk_alloc_bytes']['median']
                copy_check(source,stage/f'c{n}{label[0]}',f'{label}-r{n}',expected,run,env,receipt,verify_end)
                receipt['scope_cleanup']=reconcile(run,harnesses(),manager);assert not receipt['scope_cleanup']['unknown'];receipt['disk_budget']=disk_budget(stage);save(run/'receipt.json',receipt)
        assert len(receipt['copies'])==8 and len((run/'scopes.jsonl').read_text().splitlines())==16
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True,timeout=5).strip()==SOURCE and not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True,timeout=5)
        receipt['status']='passed';code=0
    except Exception as e:receipt.update(status='failed-or-incomplete',failure_class=type(e).__name__,failure_line=traceback.extract_tb(e.__traceback__)[-1].lineno)
    finally:
        try:
            receipt['scope_cleanup']=reconcile(run,harnesses(),manager);reap_adopted(receipt)
            receipt['remaining_outer_descendants']=sorted({int(x) for p in cg.rglob('cgroup.procs') for x in p.read_text().split()}-{os.getpid()})
            receipt['observed_pid_identities_absent']=all(ticks(r['pid'])!=r['start_ticks'] for r in receipt['observed_descendants'].values())
            receipt['cleanup_unknown']=bool(receipt['scope_cleanup']['unknown'] or receipt['remaining_outer_descendants'] or not receipt['observed_pid_identities_absent']);receipt['retained_stage_intentional']=stage is not None and stage.exists()
            if receipt['cleanup_unknown']:receipt['status']='failed-or-incomplete';code=1
        except Exception as e:receipt.update(cleanup_unknown=True,cleanup_class=type(e).__name__,status='failed-or-incomplete');code=1
        receipt['wall_seconds']=time.monotonic()-start;save(run/'receipt.json',receipt)
    print(json.dumps({'exit':code,'status':receipt['status'],'receipt':str(run/'receipt.json')}));return code
if __name__=='__main__':raise SystemExit(main())
