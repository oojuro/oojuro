#!/usr/bin/python3 -I
"""Read-only verification of the fixed retained Store diagnostic; no workload dispatch."""
import hashlib,json,math,os,pathlib,re,stat,statistics,subprocess
W=pathlib.Path(__file__).resolve().parents[2]
Q=W/'work/store-full-decode-allocation-qualification';R=Q/'comparison-attempt-1';C=Q/'comparison-controller'
read=lambda p:json.loads(p.read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def ticks(pid):
 try:return pathlib.Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[19]
 except FileNotFoundError:return None
def inventory(root):
 files=[];dirs=[]
 for parent,names,entries in os.walk(root,followlinks=False):
  parent=pathlib.Path(parent);s=parent.lstat();assert stat.S_ISDIR(s.st_mode) and s.st_uid==os.getuid()
  dirs.append({'path':parent.relative_to(root).as_posix(),'mode':stat.S_IMODE(s.st_mode),'allocated':s.st_blocks*512})
  for name in entries:
   p=parent/name;s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_uid==os.getuid()
   files.append({'path':p.relative_to(root).as_posix(),'mode':stat.S_IMODE(s.st_mode),'bytes':s.st_size,'allocated':s.st_blocks*512,'sha256':sha(p)})
  for name in names:assert stat.S_ISDIR((parent/name).lstat().st_mode)
 files.sort(key=lambda x:x['path']);dirs.sort(key=lambda x:x['path'])
 return {'snapshot_complete':True,'files':files,'directory_entries':dirs,'directories':len(dirs),'apparent_file_bytes':sum(f['bytes'] for f in files),'allocated_file_bytes':sum(f['allocated'] for f in files),'allocated_directory_bytes':sum(d['allocated'] for d in dirs),'allocated_total_bytes':sum(f['allocated'] for f in files)+sum(d['allocated'] for d in dirs)}
def equal_inventory(observed,recorded):return all(recorded[k]==v for k,v in observed.items())
r=read(R/'receipt.json');d=read(C/'dispatch-receipt.json');plan=read(C/'planned-commands.json')
assert r['status']==d['status']=='passed' and d['exit']==0 and d['cleanup_complete'] and len(r['arms'])==8 and len(r['scopes'])==33
assert all(sha(C/n)==v for n,v in plan['hashes'].items());assert all(sha(pathlib.Path(p))==plan['artifacts'][label] for label,p in plan['artifact_paths'].items())
assert [(a['round'],a['label']) for a in r['arms']]==[(n,label) for n,order in enumerate(plan['schedule']) for label in order]
stage=pathlib.Path(plan['stage']);template=read(R/'template-before.json');assert template==read(R/'template-after.json') and equal_inventory(inventory(stage/'template'),template)
proofs=[];reports=[];modes=['store-prefix','store-full','run-prefix','run-full']
for arm in r['arms']:
 assert [c['mode'] for c in arm['cases']]==modes
 for case in arm['cases']:
  name=f"r{arm['round']}-{arm['label']}-{case['mode']}";folder=R/name;raw=(folder/'probe.stdout').read_text();counts=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw);assert counts==[('ok','1','0','0')]
  bodies=[json.loads(line.split('OOJURO_CACHE_REPORT ',1)[1]) for line in raw.splitlines() if 'OOJURO_CACHE_REPORT ' in line];assert bodies==[case['report']]
  result=read(folder/'result.json');assert result==case['process'] and result['exit']==0 and sha(folder/'probe.stdout')==result['stdout_sha256'] and (folder/'probe.stdout').stat().st_size==result['stdout_bytes']
  body=bodies[0];assert all(body[k]==v for k,v in {'rows':128,'row_bytes':131072,'frames':32,'rows_per_frame':4,'cache_budget':1048576}.items());assert body['originals']==r['input']['store_originals' if case['mode'].startswith('store-') else 'run_originals']
  before=read(R/(name+'-before.json'));after=read(R/(name+'-after.json'));assert before==after==template and equal_inventory(inventory(stage/name),before)
  for p in body['phases']:
   assert math.isfinite(p['seconds']) and p['seconds']>=0
   if arm['label']=='after':assert p['body_capacity_bytes']+p['meta_capacity_bytes']+p['decoded_struct_bytes']==p['charged_cache_bytes']
   assert p['charged_cache_bytes']<=1048576
  proofs.append({'case':name,'stdout_sha256':sha(folder/'probe.stdout'),'full_original_digest':body['originals'],'inventory_unchanged':True})
  reports.append({'round':arm['round'],'label':arm['label'],**case})
for mode in modes:
 cases=[c for c in reports if c['mode']==mode];assert len(cases)==8 and len({c['report']['originals'] for c in cases})==1
 for i in range(len(cases[0]['report']['phases'])):assert len({c['report']['phases'][i]['hash'] for c in cases})==1
identities={}
for rows in [r['observed'],d['observed']]:
 for key,v in rows.items():identities[key]={'pid':v['pid'],'start_ticks':v['start_ticks']}
for v in identities.values():assert ticks(v['pid'])!=v['start_ticks']
actual_cgroups={d['identity']['cgroup']}|{s['identity']['cgroup'] for s in r['scopes']};assert len(actual_cgroups)==34
assert all(not(pathlib.Path('/sys/fs/cgroup')/p.lstrip('/')).exists() for p in actual_cgroups)
manager=pathlib.Path('<USER_CGROUP>');names={pathlib.PurePosixPath(p).name for p in actual_cgroups};remaining=[]
for parent,dirs,files in os.walk(manager):
 remaining.extend(str(pathlib.Path(parent)/n) for n in dirs if n in names)
assert not remaining and not d['sibling_scope_reconciliation']['unknown']
metrics={}
for mode in modes:
 bylabel={l:[c for c in reports if c['mode']==mode and c['label']==l] for l in ['before','after']};metrics[mode]={}
 for i,phase in enumerate(bylabel['before'][0]['report']['phases']):
  metrics[mode][phase['name']]={}
  for key in phase:
   if key in ['name','hash']:continue
   values={l:[c['report']['phases'][i][key] for c in bylabel[l]] for l in bylabel};metrics[mode][phase['name']][key]={**values,**{l+'_median':statistics.median(v) for l,v in values.items()}}
 for name,key in [('probe_max_rss_kib','probe_max_rss_kib'),('probe_wall_seconds','wall_seconds')]:
  values={l:[c['process'][key] for c in bylabel[l]] for l in bylabel};metrics[mode][name]={**values,**{l+'_median':statistics.median(v) for l,v in values.items()}}
 values={l:[c['whole_helper_probe_scope_peak_bytes'] for c in bylabel[l]] for l in bylabel};metrics[mode]['whole_helper_probe_scope_peak_bytes']={**values,**{l+'_median':statistics.median(v) for l,v in values.items()}}
pairs=[]
for n in range(4):
 for mode in modes:pairs.append({'round':n,'mode':mode,**{l:next(c for c in reports if c['round']==n and c['mode']==mode and c['label']==l) for l in ['before','after']}})
summary={'status':'C-independent-verification-passed-root-review-pending','sources':r['sources'],'artifacts':r['artifacts'],'reports':reports,'all_pairs':pairs,'metrics':metrics,'input':r['input'],'known_capacity_is_not_RSS':True,'full_scan_adverse_rounds':{mode:[p['round'] for p in pairs if p['mode']==mode and p['after']['report']['phases'][-1]['seconds']>p['before']['report']['phases'][-1]['seconds']] for mode in ['store-full','run-full']},'limits':['Warm fits-RAM highly-compressible fixed synthetic API diagnostic; shape CRC reads before timed stages.','Baseline88 versus combined prefix accounting and explicitNone initialallocation; not isolated one-expression causality.','Cross-campaign AEAD ciphertext may differ; same byte-identical closed template within campaign.','Allpairs retained; currentRSS/cumulativeHWM/wholeprobeHWM/helperCGpeak distinct; no native RecordLog CLI/hosted/cost/general claim.']}
(R/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
proof={'status':'C-independent-verification-passed-root-review-pending','raw_receipt_sha256':sha(R/'receipt.json'),'dispatch_receipt_sha256':sha(C/'dispatch-receipt.json'),'summary_sha256':sha(R/'summary.json'),'reports':proofs,'closed_inventory_pairs':33,'template_inventory':template,'identity_count':len(identities),'identities':list(identities.values()),'actual_cgroups_absent':sorted(actual_cgroups),'named_remaining':remaining,'all_originals_and_fields_checked_per_process':128,'retained_stage':str(stage),'independent_live_subset_claim':False}
(R/'independent-qualification.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'status':proof['status'],'reports':len(reports),'closed_inventory_pairs':33,'identity_count':len(identities),'cgroups_absent':len(actual_cgroups),'full_scan_adverse_rounds':summary['full_scan_adverse_rounds'],'selected':{mode:{key:metrics[mode][phase][key] for key in ['seconds','rss_kib']} for mode,phase in [('store-prefix','early_row'),('run-prefix','early_row'),('store-full','full_scan'),('run-full','full_scan')]}},indent=2))
