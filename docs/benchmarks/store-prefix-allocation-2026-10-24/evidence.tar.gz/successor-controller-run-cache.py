#!/usr/bin/python3 -I
"""One fixed four-round actual Store/RunReader cache diagnostic; no normal runtime API additions."""
import argparse,hashlib,importlib.util,json,math,os,pathlib,re,resource,shutil,subprocess,time
BASE=pathlib.Path(__file__).resolve().parent
W=BASE.parents[2]
OUT=BASE.parent
RUN=OUT/'comparison-attempt-1'
STAGE=pathlib.Path('<PRIVATE_TMP>/ojstfull-c6c1c01e')
BUILDS={'before':W/'work/store-prefix-cache-capacity-qualification/measurement-build-attempt-1/before','after':OUT/'build-attempt-1/after'}
ARTIFACTS={label:folder/'oojuro-store-libtest' for label,folder in BUILDS.items()}
SHAS={'before':'a1e97dae03fe0c9cf68a9aba4fbb4cac29311c5671790e2f92e7565fcac21313','after':'5efe2f7de34b6d15e9f678d207494c77f6d9cd65a6f327346c310201c84b5738'}
SOURCES={'before':'b66a14bc79b219c4b2f5773a4ab70d422d71b2cc','after':'b5ede496b6c5e663a0eb8c90f405f432a98c98ce'}
TREES={'before':'oojuro-store-cache-measure-before','after':'oojuro-store-cache-full-measure-after'}
HELPER_SHA='67424be4d2c9928d97094d2a4b77ced91af29598def0f0b09cb7093f2ec05557'
COMMON=W/'work/postgres-record-comparison-20261024/controller/run-comparison.py'
COMMON_SHA='b84a0f440c0ef4aafb0b019313f27806bf9166acceb7164459a8950b143b01bc'
MODES=['store-prefix','store-full','run-prefix','run-full']
SCHEDULE=[['before','after'],['after','before'],['before','after'],['after','before']]
def sha(p):
    with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def helpers():
    assert sha(COMMON)==COMMON_SHA
    spec=importlib.util.spec_from_file_location('qualified_inventory',COMMON);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main():
    p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');a=p.parse_args()
    if not a.execute:print((BASE/'planned-commands.json').read_text());return 0
    os.umask(0o077);resource.setrlimit(resource.RLIMIT_CORE,(0,0));m=helpers()
    assert all(re.fullmatch('[0-9a-f]{64}',v) for v in SHAS.values())
    for label,binary in ARTIFACTS.items():
        assert sha(binary)==SHAS[label]
        tree=W/'work'/TREES[label]
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree,text=True).strip()==SOURCES[label]
        assert not subprocess.check_output(['git','status','--porcelain'],cwd=tree,text=True)
        assert sha(tree/'crates/oojuro-store/src/reader/cache_probe.rs')==HELPER_SHA
        build=m.read_json(BUILDS[label]/'receipt.json')
        expected_status='store-cache-measurement-artifact-frozen-listed-no-workload' if label=='before' else 'store-full-read-artifact-frozen-three-checks-listed-no-diagnostic'
        assert build['source']==SOURCES[label] and build['status']==expected_status
        assert build['libtest']['sha256']==SHAS[label] and build['workloads_executed']==0 and build['tests_executed']==(0 if label=='before' else 3)
    RUN.mkdir(mode=0o700);STAGE.mkdir(mode=0o700)
    r={'status':'running','pid':os.getpid(),'start_ticks':m.ticks(os.getpid()),'phase':'preflight','arms':[],'scopes':[],'observed':{},'sources':SOURCES,'artifacts':SHAS,'scope':'optimized actual Store/RunReader API diagnostic; cache capacity/phaseRSS/cumulativeHWM/elapsed separately; not native RecordLog CLI/hosted/totalRSS-cap claim'}
    def save():m.save(RUN/'receipt.json',r)
    save();end=time.monotonic()+780;current=None
    def remaining():v=end-time.monotonic();assert v>0;return v
    def scope_query(unit):
        q=subprocess.run(['/usr/bin/systemctl','--user','show',unit,'--property=LoadState','--property=ActiveState','--property=InvocationID','--property=ControlGroup','--property=MemoryMax','--property=MemorySwapMax','--property=TasksMax','--property=RuntimeMaxUSec','--property=TimeoutStopUSec'],capture_output=True,text=True,timeout=min(5,remaining()))
        r.setdefault('scope_property_queries',[]).append({'unit':unit,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr});save()
        return dict(s.split('=',1) for s in q.stdout.splitlines() if '=' in s)
    def measure(label,root,name,mode):
        nonlocal current
        folder=RUN/name;folder.mkdir(mode=0o700)
        selected='before' if label=='prepare' else label
        control={'binary':str(ARTIFACTS[selected]),'binary_sha256':SHAS[selected],'root':str(root),'mode':mode,'stdout':str(folder/'probe.stdout'),'stderr':str(folder/'probe.stderr'),'result':str(folder/'result.json'),'ack':str(folder/'peak-read.ack')}
        m.save(folder/'control.json',control)
        unit=f'oojuro-store-cache-{label}-{os.getpid()}-{time.monotonic_ns()}.scope'
        command=['/usr/bin/systemd-run','--user','--scope','--quiet','--collect','--unit='+unit,'--property=MemoryMax=512M','--property=MemorySwapMax=0','--property=TasksMax=128','--property=RuntimeMaxSec=60','--property=TimeoutStopSec=5','--','/usr/bin/python3','-I',str(BASE/'measure-one.py'),str(folder/'control.json')]
        row={'name':name,'mode':mode,'unit':unit,'command':command};r['scopes'].append(row);save()
        with (folder/'scope.stdout').open('xb') as out,(folder/'scope.stderr').open('xb') as err:
            current=subprocess.Popen(command,stdout=out,stderr=err);row.update(wrapper_pid=current.pid,wrapper_start=m.ticks(current.pid));save();cg=None;ack=False;deadline=time.monotonic()+min(75,remaining())
            while current.poll() is None:
                if cg is None:
                    fields=scope_query(unit)
                    if fields.get('ActiveState')=='active' and fields.get('ControlGroup'):
                        row['identity']={'invocation':fields['InvocationID'],'cgroup':fields['ControlGroup']};save()
                        assert re.fullmatch('[0-9a-f]{32}',fields['InvocationID']) and fields['ControlGroup'].endswith('/'+unit)
                        assert all(fields[k]==v for k,v in {'MemoryMax':str(512<<20),'MemorySwapMax':'0','TasksMax':'128','RuntimeMaxUSec':'1min','TimeoutStopUSec':'5s'}.items())
                        cg=pathlib.Path('/sys/fs/cgroup')/fields['ControlGroup'].lstrip('/')
                if cg is not None and cg.exists():
                    for f in cg.rglob('cgroup.procs'):
                        for token in f.read_text().split():
                            pid=int(token);start=m.ticks(pid)
                            if start:r['observed'].setdefault(f'{pid}:{start}',{'pid':pid,'start_ticks':start,'cgroup':str(f.parent)})
                    if not ack and (folder/'result.json').exists():
                        result=m.read_json(folder/'result.json');assert result['helper_cgroup']=='0::'+row['identity']['cgroup']
                        row['cgroup_memory_peak_bytes']=int((cg/'memory.peak').read_text());row['result']=result
                        r['observed'].setdefault(f"{result['probe_pid']}:{result['probe_start_ticks']}",{'pid':result['probe_pid'],'start_ticks':result['probe_start_ticks'],'cgroup':str(cg),'source':'owned helper captured before wait'})
                        save()
                        fd=os.open(folder/'peak-read.ack',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);os.close(fd);ack=True
                assert time.monotonic()<deadline;time.sleep(.02)
            row['scope_exit']=current.returncode;save();assert current.returncode==0 and ack
        fields=scope_query(unit);assert fields.get('LoadState')=='not-found' or fields.get('ActiveState')=='inactive'
        assert not cg.exists() and m.ticks(row['wrapper_pid'])!=row['wrapper_start'];row['cgroup_absent']=True
        stdout=(folder/'probe.stdout').read_text();assert len(stdout.encode())<=1<<20
        assert re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',stdout)==[('ok','1','0','0')]
        prefix='OOJURO_CACHE_TEMPLATE ' if mode=='prepare' else 'OOJURO_CACHE_REPORT '
        bodies=[line.split(prefix,1)[1] for line in stdout.splitlines() if prefix in line];assert len(bodies)==1
        return row,json.loads(bodies[0])
    try:
        r['phase']='template-create';save();template=STAGE/'template';template.mkdir(mode=0o700)
        _,fixed=measure('prepare',template,'prepare','prepare')
        assert all(fixed[k]==v for k,v in {'rows':128,'row_bytes':131072,'frames':32,'rows_per_frame':4,'cache_budget':1<<20}.items())
        assert all(re.fullmatch('[0-9a-f]{64}',fixed[k]) for k in ['store_originals','run_originals'])
        r['input']=fixed;save();before=m.inventory(template);m.save(RUN/'template-before.json',before)
        for n,order in enumerate(SCHEDULE):
            for label in order:
                cases=[]
                for mode in MODES:
                    name=f'r{n}-{label}-{mode}';r['phase']=name;save();root=STAGE/name
                    shutil.copytree(template,root,copy_function=shutil.copy2)
                    initial=m.inventory(root);assert m.inventory_equal(before,initial);m.save(RUN/(name+'-before.json'),initial)
                    row,body=measure(label,root,name,mode)
                    assert body['mode']==mode and all(body[k]==fixed[k] for k in ['rows','row_bytes','frames','rows_per_frame','cache_budget'])
                    assert body['originals']==fixed['store_originals' if mode.startswith('store-') else 'run_originals']
                    expected_phases=['open','prefix','early_row'] if mode.endswith('prefix') else ['open','full_scan']
                    assert [p['name'] for p in body['phases']]==expected_phases
                    for p in body['phases']:
                        assert math.isfinite(p['seconds']) and p['seconds']>=0 and all(type(p[k]) is int and p[k]>=0 for k in ['rss_kib','cumulative_hwm_kib','entries','body_capacity_bytes','meta_capacity_bytes','decoded_struct_bytes','charged_cache_bytes'])
                        assert p['charged_cache_bytes']<=1<<20 and p['entries']<=32
                        if label=='after':assert p['body_capacity_bytes']+p['meta_capacity_bytes']+p['decoded_struct_bytes']==p['charged_cache_bytes']
                        if p['name']=='full_scan':assert p['hash']==body['originals']
                    closed=m.inventory(root);assert initial==closed;m.save(RUN/(name+'-after.json'),closed)
                    cases.append({'mode':mode,'report':body,'process':row['result'],'whole_helper_probe_scope_peak_bytes':row['cgroup_memory_peak_bytes'],'closed_copy_unchanged':True})
                    assert m.inventory(STAGE)['allocated_total_bytes']<=256<<20 and shutil.disk_usage('/var/tmp').free>=1<<30
                r['arms'].append({'round':n,'label':label,'cases':cases});save()
        after=m.inventory(template);assert before==after;m.save(RUN/'template-after.json',after)
        assert len(r['arms'])==8 and len(r['scopes'])==33
        for mode in MODES:
            bodies=[c['report'] for arm in r['arms'] for c in arm['cases'] if c['mode']==mode]
            assert len(bodies)==8 and len({b['originals'] for b in bodies})==1
            for p in range(len(bodies[0]['phases'])):assert len({b['phases'][p]['hash'] for b in bodies})==1
        assert all(m.ticks(v['pid'])!=v['start_ticks'] for v in r['observed'].values())
        r.update(status='passed',phase='terminal',template_unchanged=True,stage_retained=str(STAGE));save();return 0
    except Exception as error:
        tb=error.__traceback__
        while tb.tb_next is not None:tb=tb.tb_next
        r.update(status='failed-or-incomplete',failure_class=type(error).__name__,failure_site={'file':pathlib.Path(tb.tb_frame.f_code.co_filename).name,'line':tb.tb_lineno});save();return 1
    finally:
        if current is not None and current.poll() is None:current.kill();current.wait(timeout=5)
        save()

def reconcile(run,body,manager):
    m=helpers();harness_pids=[body['pid']]
    assert all(type(pid) is int and pid>0 for pid in harness_pids)
    manager=pathlib.Path(manager)
    assert manager==pathlib.Path(f'/sys/fs/cgroup/user.slice/user-{os.getuid()}.slice/user@{os.getuid()}.service')
    end=time.monotonic()+100;rows=[];unknown=[]
    def issue(phase,error):unknown.append({'phase':phase,'class':type(error).__name__})
    records=body['scopes'];assert len(records)<=33
    identities={row['unit']:{'invocation_id':row['identity']['invocation'],'control_group':row['identity']['cgroup']} for row in records if row.get('identity')}
    observed={row['unit']:[row['identity']['cgroup']] for row in records if row.get('identity')}
    def path(unit,value):
        assert isinstance(value,str) and value.startswith('/') and '..' not in pathlib.PurePosixPath(value).parts
        p=pathlib.Path('/sys/fs/cgroup')/value.lstrip('/')
        assert p.is_relative_to(manager) and p.name==unit
        return p
    for entry in records:
        item={'queries':[]};rows.append(item)
        try:
            record=dict(entry,harness_pid=body['pid'],launcher_pid=entry['wrapper_pid'],start_ticks=entry['wrapper_start']);unit=record['unit'];item['inventory']=record
            assert record['harness_pid'] in harness_pids and re.fullmatch(r'oojuro-store-cache-(before|after|prepare)-'+str(record['harness_pid'])+r'-[0-9]+\.scope',unit)
            def query():
                left=end-time.monotonic();assert left>0
                args=['/usr/bin/systemctl','--user','show',unit,'--property=LoadState','--property=ActiveState','--property=ControlGroup','--property=InvocationID']
                q=subprocess.run(args,capture_output=True,text=True,timeout=min(5,left))
                item['queries'].append({'command':args,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr})
                m.save(run/'scope-reconciliation.json',{'rows':rows,'unknown':unknown})
                v=dict(x.split('=',1) for x in q.stdout.splitlines() if '=' in x)
                if v.get('ControlGroup'):
                    actual=v['ControlGroup'];path(unit,actual)
                    if actual not in observed.setdefault(unit,[]):observed[unit].append(actual);m.save(run/'scope-observations.json',observed)
                return v
            v=query()
            if v.get('ActiveState') in ['active','activating','deactivating','failed']:
                if unit not in identities:
                    assert m.ticks(record['launcher_pid'])==record['start_ticks']
                    assert pathlib.Path(f"/proc/{record['launcher_pid']}/cgroup").read_text().strip()=='0::'+v['ControlGroup']
                    assert re.fullmatch('[0-9a-f]{32}',v['InvocationID'])
                    identities[unit]={'invocation_id':v['InvocationID'],'control_group':v['ControlGroup']}
                    m.save(run/'scope-identities.json',identities)
                for action in [['kill','--signal=KILL','--kill-whom=all',unit],['stop',unit]]:
                    v=query();identity=identities[unit]
                    if v.get('LoadState')=='not-found' or v.get('ActiveState')=='inactive':break
                    assert v['InvocationID']==identity['invocation_id'] and v['ControlGroup']==identity['control_group']
                    left=end-time.monotonic();assert left>0
                    q=subprocess.run(['/usr/bin/systemctl','--user',*action],capture_output=True,text=True,timeout=min(5,left))
                    item.setdefault('termination',[]).append({'action':action,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr})
                    m.save(run/'scope-reconciliation.json',{'rows':rows,'unknown':unknown})
            until=min(end,time.monotonic()+5)
            while True:
                v=query();dead=v.get('LoadState')=='not-found' or v.get('ActiveState')=='inactive'
                actual_absent=all(not path(unit,p).exists() for p in observed.get(unit,[]))
                named=[];count=0
                def failed(error):raise error
                if dead:
                    for parent,dirs,files in os.walk(manager,onerror=failed):
                        count+=1;assert count<=4096 and time.monotonic()<end
                        if unit in dirs:named.append(str(pathlib.Path(parent)/unit))
                if dead and actual_absent and not named and m.ticks(record['launcher_pid'])!=record['start_ticks']:break
                assert time.monotonic()<until;time.sleep(.05)
            item.update(status='reconciled',actual_paths_absent=actual_absent,exact_named_paths_remaining=named,original_pid_identity_absent=True)
        except Exception as error:item['status']='unknown';issue('scope',error)
    result={'rows':rows,'unknown':unknown,'manager_hierarchy':str(manager)}
    m.save(run/'scope-reconciliation.json',result);return result

if __name__=='__main__':raise SystemExit(main())
