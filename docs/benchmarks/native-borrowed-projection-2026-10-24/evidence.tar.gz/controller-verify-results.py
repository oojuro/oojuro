import pathlib,json,hashlib,importlib.util,math,statistics,datetime,subprocess
B=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('frozen_comparison',B/'run-comparison.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
assert m.sha(B/'run-comparison.py')=='d6540f2c0a6fd9eb8f08a56036dcc19d747b5e72a02d5c5158abf4efacfc5a9b'
plan=m.read_json(B/'planned-commands.json');run=pathlib.Path(plan['run']);r=m.read_json(run/'receipt.json');d=m.read_json(B/'dispatch-receipt.json')
assert r['status']=='passed' and d['exit']==d['unit_exit']==0 and d['cleanup_complete'] and not r['cleanup_unknown']
assert len(r['records'])==4 and len(r['copies'])==8 and len((run/'scopes.jsonl').read_text().splitlines())==16
for p,h in plan['artifacts'].items():assert m.sha(pathlib.Path(p))==h
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=m.ROOT,text=True).strip()==m.SOURCE and not subprocess.check_output(['git','status','--porcelain'],cwd=m.ROOT)
expected=m.expected_swe();assert len(expected)==20623
quality_rows=[];cards=[];all_queries={}
for n in range(4):
 card=m.read_json(run/f'round-{n}.json');assert card==r['records'][n]['card'];assert card['settings']['steps']==201 and card['settings']['runs']==1
 assert [x['label'] for x in card['arms']]==(['native','current'] if n%2==0 else ['current','native']);cards.append(card)
 qbyarm={}
 for arm in card['arms']:
  label=arm['label'];assert not arm['error'] and all(x['pass'] for x in arm['gates'].values());assert arm['speed']['store_records_end']['median']==20623
  assert arm['info']['commit']==(m.SOURCE if label=='current' else m.NATIVE_SOURCE)[:12]
  assert arm['info']['name']=='native-record'
  raw=(run/f'pools-round-{n}.{label}').read_bytes();pool=[json.loads(x) for x in raw.split(b'\n') if x];assert len(pool)==52
  assert raw==m.REFERENCE.read_bytes()
  metrics={k:[] for k in ['ndcg@10','ndcg@20','recall@20','mrr@10','hit@20']};metadata=[]
  for row in pool:
   ranked=[x[0] for x in row['hits']][:20];assert len(ranked)==len(set(ranked));rel={k:v for k,v in row['relevant'].items() if v>0};assert rel
   for ident in ranked:assert ident in expected
   metadata.append({k:v for k,v in row.items() if k!='hits'})
   for k in [10,20]:
    dcg=sum(rel.get(id,0)/math.log2(i+2) for i,id in enumerate(ranked[:k]));ideal=sum(v/math.log2(i+2) for i,v in enumerate(sorted(rel.values(),reverse=True)[:k]));metrics[f'ndcg@{k}'].append(dcg/ideal if ideal else 0)
   relevant=[i for i,id in enumerate(ranked) if id in rel];metrics['recall@20'].append(len(relevant)/len(rel));metrics['hit@20'].append(float(bool(relevant)));metrics['mrr@10'].append(next((1/(i+1) for i in relevant if i<10),0))
  for k,values in metrics.items():assert math.isclose(statistics.mean(values),arm['quality'][k]['median'],rel_tol=1e-12,abs_tol=1e-12)
  qbyarm[label]=metadata;quality_rows.append({'round':n,'arm':label,'labelled_queries':52,'pool_sha256':hashlib.sha256(raw).hexdigest(),'recomputed':{k:statistics.mean(v) for k,v in metrics.items()}})
 assert qbyarm['native']==qbyarm['current'];all_queries[n]=qbyarm['native']
for n in range(1,4):assert all_queries[n]==all_queries[0]
copy_proofs=[]
for item in r['copies']:
 label=item['label'];iscurrent=label.startswith('current-');n=int(label.rsplit('r',1)[1]);source=pathlib.Path(r['retained_stage'])/f'w/r{n}'/('current' if iscurrent else 'native')/'run0-turnloop/store';destination=pathlib.Path(r['retained_stage'])/f'c{n}'+pathlib.Path('') if False else pathlib.Path(r['retained_stage'])/f'c{n}{"c" if iscurrent else "n"}'
 assert m.inventory(source)==item['inventory'] and m.inventory(destination)==item['copy_inventory_after']
 assert m.inventory_equal(item['inventory'],item['copy_inventory_before'])
 requests=[json.loads(x) for x in (run/(label+'.stdin')).read_bytes().split(b'\n') if x];responses=[json.loads(x) for x in (run/(label+'.stdout')).read_bytes().split(b'\n') if x]
 assert len(requests)==len(responses) and all(x['ok'] is True for x in responses)
 assert requests[1]['dir']==str(destination)
 docs=[];gets=0
 for req,response in zip(requests,responses):
  if req['op']=='get_range':docs.extend(m.normalized(x) for x in response['docs'])
  if req['op']=='get':assert response['texts']==[expected[id]['text'] if id in expected else None for id in req['ids']];gets+=len([id for id in req['ids'] if id in expected])
 assert len(docs)==len(expected) and len({x['id'] for x in docs})==len(expected) and all(x==expected[x['id']] for x in docs) and gets==len(expected)
 assert [x['valid_at'] for x in docs]==sorted(x['valid_at'] for x in docs)
 copy_proofs.append({'label':label,'docs':len(docs),'gets':gets,'all_fields_and_originals_match_raw_fixture':True,'source_and_copy_current_inventories_match':True,'protocol_log_sha256':m.sha(run/(label+'.stdout'))})
metrics={section:list(cards[0]['arms'][0][section]) for section in ['speed','memory','storage','quality']}
summary={}
for label in ['native','current']:
 arms=[next(x for x in card['arms'] if x['label']==label) for card in cards];summary[label]={section:{key:{'rounds':[a[section][key]['median'] for a in arms],'median_of_rounds':statistics.median(a[section][key]['median'] for a in arms)} for key in keys} for section,keys in metrics.items()}
# Independent current resource check; no signals or unit actions.
identities={}
for row in r['observed_descendants'].values():identities[(row['pid'],row['start_ticks'])]=row
for child in r['children']:identities[(child['pid'],child['start_ticks'])]=child
for row in [json.loads(x) for x in (run/'scopes.jsonl').read_text().splitlines()]:identities[(row['launcher_pid'],row['start_ticks'])]={'pid':row['launcher_pid'],'start_ticks':row['start_ticks']}
identity=d['identity'];identities[(identity['pid'],identity['start_ticks'])]=dict(pid=identity['pid'],start_ticks=identity['start_ticks'])
assert all(m.ticks(pid)!=start for pid,start in identities)
assert not pathlib.Path('/proc',str(d['wrapper_pid'])).exists()
actual={identity['cgroup']}
observations=m.read_json(run/'scope-observations.json')
for paths in observations.values():actual.update(paths)
assert len(actual)==17 and all(not (pathlib.Path('/sys/fs/cgroup')/p.lstrip('/')).exists() for p in actual)
manager=pathlib.Path('<USER_CGROUP>');names={pathlib.PurePosixPath(p).name for p in actual};remaining=[]
import os
for parent,dirs,files in os.walk(manager):remaining.extend(str(pathlib.Path(parent)/name) for name in dirs if name in names)
assert not remaining and not d['outside_scope_cleanup']['unknown']
resources={'observed_pid_start_identities_absent':len(identities),'identities':[{'pid':pid,'start_ticks':start} for pid,start in identities],'actual_and_named_cgroups_absent':sorted(actual),'wrapper_absent':True,'no_remaining_named_groups':True,'retained_stores_intentional':r['retained_stage_intentional']}
proof={'status':'C-independently-qualified-four-current-borrowed-pairs-and8-full-copies-root-review-pending','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':m.SOURCE,'native_source':m.NATIVE_SOURCE,'timed_queries_per_arm':804,'distinct_labelled_queries':52,'labelled_lists_per_arm':208,'quality_recomputed_from_all_saved_pools':True,'quality_rows':quality_rows,'copies':copy_proofs,'worker_wall_seconds':r['wall_seconds'],'summary':summary,'resources':resources,'limits':['Warm local fits-RAM fixed20k-background selection, not allrawrows/largerthanRAM/OS-cold/hosted/SOTA.','Four repeated rounds contain52distinct labelled queries;804queries/arm timed, all804ranklists/timings not separately retained.','Current4a/c129 compared with shared-streaming9190+borrowed-caller4c/bcf; cannot isolate core refresh and caller contributions.','All memorycategories/tails/adversepairs retained; no pooledpercentile or sumofpeaks claim.']}
m.save(B/'independent-qualification.json',proof);m.save(B/'results-summary.json',{'summary':summary,'limits':proof['limits']})
selected={label:{section:{key:summary[label][section][key] for key in keys} for section,keys in {'speed':['search_p50_us','search_p99_us','search_get_p50_us','search_get_p99_us','append_p50_us','append_p99_us','returned_original_bytes'],'memory':['peak_rss_bytes','peak_cgroup_bytes','steady_rss_bytes','steady_cgroup_bytes','steady_anon_bytes','steady_file_bytes'],'storage':['disk_bytes','disk_alloc_bytes']}.items()} for label in ['native','current']}
print(json.dumps({'status':proof['status'],'copies':len(copy_proofs),'timed_queries_per_arm':804,'resources':{k:v for k,v in resources.items() if k!='identities'},'selected':selected},indent=2))
