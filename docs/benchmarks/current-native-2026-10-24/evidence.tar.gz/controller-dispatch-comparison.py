#!/usr/bin/python3 -I
"""Dispatch fixed paired native84/current-native SWE comparison; identity-checked exact-unit cleanup."""
import argparse,importlib.util,json,os,pathlib,subprocess,time
BASE=pathlib.Path(__file__).resolve().parent

def main():
    p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');a=p.parse_args()
    plan=json.loads((BASE/'planned-commands.json').read_text());cmd=plan['outer']
    if not a.execute:print(json.dumps(plan,indent=2));return 0
    assert not (BASE/'dispatch-receipt.json').exists() and not pathlib.Path(plan['run']).exists()
    spec=importlib.util.spec_from_file_location('projection_budget_controller',BASE/'run-comparison.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    assert all(m.sha(BASE/name)==digest for name,digest in plan['hashes'].items())
    assert all(m.sha(pathlib.Path(p))==digest for p,digest in plan['artifacts'].items())
    unit=plan['unit'];run=pathlib.Path(plan['run']);r={'command':cmd,'queries':[]};identity=None;process=None;code=1
    def save():m.save(BASE/'dispatch-receipt.json',r)
    def query():
        q=subprocess.run(['/usr/bin/systemctl','--user','show',unit,'--property=LoadState','--property=ActiveState','--property=SubState','--property=MainPID','--property=InvocationID','--property=ControlGroup','--property=MemoryMax','--property=MemorySwapMax','--property=TasksMax','--property=RuntimeMaxUSec','--property=TimeoutStopUSec','--property=KillMode','--property=LimitCORE'],capture_output=True,text=True,timeout=5)
        r['queries'].append({'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr});save()
        return dict(x.split('=',1) for x in q.stdout.splitlines() if '=' in x)
    try:
        with (BASE/'dispatch.stdout').open('xb') as out,(BASE/'dispatch.stderr').open('xb') as err:
            process=subprocess.Popen(cmd,stdout=out,stderr=err);r['wrapper_pid']=process.pid;save();until=time.monotonic()+10
            while True:
                f=query()
                if f.get('ActiveState')=='active' and f.get('ControlGroup'):
                    identity={'invocation':f['InvocationID'],'cgroup':f['ControlGroup'],'pid':int(f['MainPID'])};r['identity']=identity
                    identity['start_ticks']=m.ticks(identity['pid']);save()
                    assert identity['cgroup'].endswith('/'+unit) and identity['pid']>0 and identity['start_ticks']
                    assert all(f[k]==v for k,v in {'MemoryMax':str(6<<30),'MemorySwapMax':'0','TasksMax':'512','RuntimeMaxUSec':'42min','TimeoutStopUSec':'5s','KillMode':'control-group','LimitCORE':'0'}.items());break
                if process.poll() is not None:r['observer_missed_live_outer']=True;break
                assert time.monotonic()<until;time.sleep(.05)
            r['unit_exit']=process.wait(timeout=2550);code=r['unit_exit'];save()
    except Exception as e:r.update(status='observer-or-unit-refused',error_class=type(e).__name__);save()
    finally:
        if process is not None and process.poll() is None:
            try:
                f=query()
                if identity and f.get('InvocationID')==identity['invocation'] and f.get('ControlGroup')==identity['cgroup']:
                    for action in [['kill','--signal=KILL','--kill-whom=all',unit],['stop',unit]]:
                        f=query()
                        if f.get('LoadState')=='not-found' or f.get('ActiveState')=='inactive':break
                        assert f['InvocationID']==identity['invocation'] and f['ControlGroup']==identity['cgroup']
                        q=subprocess.run(['/usr/bin/systemctl','--user',*action],capture_output=True,text=True,timeout=10)
                        r.setdefault('termination',[]).append({'command':action,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr});save()
                if process.poll() is None:
                    try:process.wait(timeout=10)
                    except subprocess.TimeoutExpired:process.kill();process.wait(timeout=5)
            except Exception as e:r['outer_cleanup_error_class']=type(e).__name__;code=1
        try:
            r['terminal']=query();body=m.read_json(run/'receipt.json')
            if not identity:raise ValueError('no observed outer identity')
            manager=pathlib.Path('/sys/fs/cgroup')/identity['cgroup'].split('/app.slice/',1)[0].lstrip('/')
            harnesses=[r for r in body.get('children',[]) if r['label'].startswith('round-')]
            r['outside_scope_cleanup']=m.reconcile(run,[identity['pid'],*[h['pid'] for h in harnesses]],manager)
            cg=pathlib.Path('/sys/fs/cgroup')/identity['cgroup'].lstrip('/')
            r['outer_cgroup_absent']=not cg.exists();r['original_outer_pid_absent']=m.ticks(identity['pid'])!=identity['start_ticks']
            r['original_harness_absent']=all(m.ticks(h['pid'])!=h['start_ticks'] for h in harnesses)
            r['retained_stores_intentional']=body.get('retained_stage_intentional',False);r['observed_descendant_identities_absent']=all(m.ticks(x['pid'])!=x['start_ticks'] for x in body.get('observed_descendants',{}).values())
            r['cleanup_complete']=not r['outside_scope_cleanup']['unknown'] and all(r[k] for k in ['outer_cgroup_absent','original_outer_pid_absent','original_harness_absent','observed_descendant_identities_absent'])
            if not r['cleanup_complete'] or body['status']!='passed':code=1
        except Exception as e:r.update(outside_cleanup_error_class=type(e).__name__,cleanup_complete=False);code=1
        r['exit']=code;save()
    print(json.dumps({'exit':code,'receipt':str(BASE/'dispatch-receipt.json'),'unit':unit}));return code
if __name__=='__main__':raise SystemExit(main())
