#!/usr/bin/python3 -I
"""Fixed32-row, eight-copy actual production CLI allocation diagnostic."""
import argparse,hashlib,importlib.util,json,os,pathlib,re,shutil,stat,subprocess,time
BASE=pathlib.Path(__file__).resolve().parent
W=BASE.parents[2]
OUT=BASE.parent
RUN=OUT/'context-attempt-3'
STAGE=pathlib.Path('<FIXTURE>/251cf8e4')
ARTIFACTS={'before':OUT/'before/oojuro-native','after':OUT/'after/oojuro-native'}
SHAS={'before':'42d1d4ba03c921d584b7ad54de1365d3fabbe472067c0c859965a3965dc78eb7','after':'cd270843f75412ce77ac70ff13296d7aeb3a1ad4197e56a8e3051dafca8f2339'}
COMMON=W/'work/postgres-record-comparison-20261024/controller/run-comparison.py'
COMMON_SHA='b84a0f440c0ef4aafb0b019313f27806bf9166acceb7164459a8950b143b01bc'

def sha(p):
    with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def helpers():
    assert sha(COMMON)==COMMON_SHA
    spec=importlib.util.spec_from_file_location('qualified_inventory',COMMON);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main():
    p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');a=p.parse_args();assert a.execute
    os.umask(0o077);m=helpers();RUN.mkdir(mode=0o700);STAGE.mkdir(mode=0o700)
    r={'status':'running','pid':os.getpid(),'start_ticks':m.ticks(os.getpid()),'phase':'preflight','arms':[],'scopes':[],'observed':{},'source_runtime':'09b0fbd943625a031698fb52cd574b006b31786a','test_only_source':'631c19cd1ecfe9ecc7ee99379c8ef9e5c49896ce','scope':'actual opt0 native Record CLI allocation diagnostic; no release speed/hosted/general search claim'}
    def save():m.save(RUN/'receipt.json',r)
    save();end=time.monotonic()+780;current=None;reference_watermark=None
    def remaining():v=end-time.monotonic();assert v>0;return v
    def cli(binary,root,command,args,cap=2<<20):
        nonlocal current
        cmd=[str(binary),command,'--root',str(root),*args]
        current=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        out,err=current.communicate(timeout=min(30,remaining()))
        assert len(out)<=cap and len(err)<=65536 and current.returncode==0
        return json.loads(out)
    def all_records(root,expected=None):
        nonlocal reference_watermark
        # One complete public page, not32 repeated log reopens. No payload log.
        page=cli(ARTIFACTS['before'],root,'record-range',['--versions','all','--entries','33','--bytes','33554432'],cap=32<<20)
        assert set(page)=={'watermark','records','next'} and page['next'] is None
        values=sorted(page['records'],key=lambda row:row['id'])
        assert len(values)==32 and [x['id'] for x in values]==list(range(1,33))
        watermark=page['watermark']
        assert set(watermark)=={'schema','origin','identity','sequence','records','commitment'}
        seal=watermark['commitment'];assert isinstance(seal,list) and 0<len(seal)<=256 and all(type(b) is int and 0<=b<=255 for b in seal)
        # tip() freshly AEAD-seals the same prefix with a random nonce; native
        # View::range validates that seal. Compare only exposed prefix fields.
        semantic={k:watermark[k] for k in ['schema','origin','identity','sequence','records']}
        assert semantic['schema']==1 and semantic['sequence']==4 and semantic['records']==32
        if reference_watermark is None:reference_watermark=semantic
        else:assert semantic==reference_watermark
        if expected is not None:assert values==expected
        return values
    def scope_query(unit):
        q=subprocess.run(['/usr/bin/systemctl','--user','show',unit,'--property=LoadState','--property=ActiveState','--property=InvocationID','--property=ControlGroup','--property=MemoryMax','--property=MemorySwapMax','--property=TasksMax','--property=RuntimeMaxUSec','--property=TimeoutStopUSec'],capture_output=True,text=True,timeout=min(5,remaining()))
        r.setdefault('scope_property_queries',[]).append({'unit':unit,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr});save()
        return dict(s.split('=',1) for s in q.stdout.splitlines() if '=' in s)
    try:
        for label,p in ARTIFACTS.items():assert sha(p)==SHAS[label]
        checks=m.read_json(OUT/'checks-continuation-1/receipt.json');assert checks['status']=='three-selectors-passed-cli-runtime-unchanged' and checks['exit']==0
        r['phase']='fixture-create';save();source=STAGE/'source'
        cli(ARTIFACTS['before'],source,'record-setup',['--writer','synthetic-counted-search','--owner','1','--first-id','1','--adapter','synthetic-counted-search'])
        inputs=[{'agent_id':'synthetic-reported','parent_id':None,'valid_at':i+1,'kind':'explicit','tool':None,'status':None,'exit':None,'key':None,'text':'needle '+('\0'*131072) if i<31 else 'needle compact exact context','attrs':{},'indexed':True} for i in range(32)]
        # JSON input is an intentional synthetic CLI fixture, never a history import.
        for batch in range(4):
            path=STAGE/f'input-{batch}.json';raw=json.dumps(inputs[batch*8:batch*8+8],ensure_ascii=False,separators=(',',':')).encode();assert len(raw)<32<<20
            path.write_bytes(raw);path.chmod(0o600)
            cli(ARTIFACTS['before'],source,'record-append',['--request',f'fixture-{batch}','--input',str(path),'--allow-unredacted-records']);path.unlink()
        expected=all_records(source)
        for got,input_value in zip(expected,inputs):
            assert all(got[k]==input_value[k] for k in input_value) and got['writer']=='synthetic-counted-search' and got['adapter']=='synthetic-counted-search'
        r['reference']={'records':32,'watermark_semantic_sha256':hashlib.sha256(json.dumps(reference_watermark,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'text_bytes':sum(len(v['text'].encode()) for v in expected),'canonical_sha256':hashlib.sha256(json.dumps(expected,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
        source_before=m.inventory(source);m.save(RUN/'source-before.json',source_before)
        expected_context=None
        for round_number,order in enumerate([['before','after'],['after','before'],['before','after'],['after','before']]):
            for label in order:
                r['phase']=f'round-{round_number}-{label}';save();name=f'r{round_number}-{label}';root=STAGE/name;shutil.copytree(source,root,symlinks=True)
                before=m.inventory(root);assert m.inventory_equal(source_before,before);m.save(RUN/(name+'-before.json'),before)
                all_records(root,expected) # Same single full-page warming operation for both arms.
                folder=RUN/name;folder.mkdir(mode=0o700)
                control={'binary':str(ARTIFACTS[label]),'binary_sha256':SHAS[label],'root':str(root),'stdout':str(folder/'context.stdout'),'stderr':str(folder/'context.stderr'),'result':str(folder/'result.json'),'ack':str(folder/'peak-read.ack')}
                m.save(folder/'control.json',control)
                unit=f'oojuro-record-context-{label}-{os.getpid()}-{time.monotonic_ns()}.scope'
                command=['/usr/bin/systemd-run','--user','--scope','--quiet','--collect','--unit='+unit,'--property=MemoryMax=3G','--property=MemorySwapMax=0','--property=TasksMax=512','--property=RuntimeMaxSec=120','--property=TimeoutStopSec=5','--','/usr/bin/python3','-I',str(BASE/'measure-one.py'),str(folder/'control.json')]
                row={'name':name,'unit':unit,'command':command};r['scopes'].append(row);save()
                with (folder/'scope.stdout').open('xb') as out,(folder/'scope.stderr').open('xb') as err:
                    current=subprocess.Popen(command,stdout=out,stderr=err);row.update(wrapper_pid=current.pid,wrapper_start=m.ticks(current.pid));save();cg=None;ack=False;deadline=time.monotonic()+min(140,remaining())
                    while current.poll() is None:
                        if cg is None:
                            fields=scope_query(unit)
                            if fields.get('ActiveState')=='active' and fields.get('ControlGroup'):
                                row['identity']={'invocation':fields['InvocationID'],'cgroup':fields['ControlGroup']};save()
                                assert re.fullmatch('[0-9a-f]{32}',fields['InvocationID']) and fields['ControlGroup'].endswith('/'+unit)
                                assert all(fields[k]==v for k,v in {'MemoryMax':str(3<<30),'MemorySwapMax':'0','TasksMax':'512','RuntimeMaxUSec':'2min','TimeoutStopUSec':'5s'}.items())
                                cg=pathlib.Path('/sys/fs/cgroup')/fields['ControlGroup'].lstrip('/')
                        if cg is not None and cg.exists():
                            for f in cg.rglob('cgroup.procs'):
                                for token in f.read_text().split():
                                    pid=int(token);start=m.ticks(pid)
                                    if start:r['observed'].setdefault(f'{pid}:{start}',{'pid':pid,'start_ticks':start,'cgroup':str(f.parent)})
                            if not ack and (folder/'result.json').exists():
                                result=m.read_json(folder/'result.json');assert result['helper_cgroup']=='0::'+row['identity']['cgroup']
                                row['cgroup_memory_peak_bytes']=int((cg/'memory.peak').read_text());row['result']=result;save()
                                fd=os.open(folder/'peak-read.ack',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);os.close(fd);ack=True
                        assert time.monotonic()<deadline;time.sleep(.02)
                    row['scope_exit']=current.returncode;save();assert current.returncode==0 and ack
                fields=scope_query(unit);assert fields.get('LoadState')=='not-found' or fields.get('ActiveState')=='inactive'
                assert not cg.exists() and m.ticks(row['wrapper_pid'])!=row['wrapper_start'];row['cgroup_absent']=True
                raw=(folder/'context.stdout').read_bytes();assert len(raw)<=65536
                value=json.loads(raw);assert value['measurement']=='unicode-chars-div4-estimate-v1' and value['hard_provider_token_cap'] is False
                envelope=json.loads(value['hookSpecificOutput']['additionalContext']);assert len(envelope['items'])==1 and envelope['items'][0]['record']==expected[-1]
                if expected_context is None:expected_context=raw
                else:assert raw==expected_context
                all_records(root,expected);after=m.inventory(root);assert after==before;m.save(RUN/(name+'-after.json'),after)
                r['arms'].append({'round':round_number,'label':label,'name':name,'records_before_after':32,'all_record_fields_equal':True,'full_context_bytes_equal':True,'context_sha256':hashlib.sha256(raw).hexdigest(),'context_bytes':len(raw),'wall_seconds':row['result']['wall_seconds'],'cli_max_rss_kib':row['result']['cli_max_rss_kib'],'whole_scope_memory_peak_bytes':row['cgroup_memory_peak_bytes'],'copied_store_unchanged':True});save()
        all_records(source,expected);source_after=m.inventory(source);assert source_after==source_before;m.save(RUN/'source-after.json',source_after)
        assert len(r['arms'])==8 and all(m.ticks(v['pid'])!=v['start_ticks'] for v in r['observed'].values())
        r.update(status='passed',phase='terminal',source_unchanged=True,stage_retained=str(STAGE),no_release_speed_claim=True,no_cold_os_or_ordinary_small_result_gain_claim=True);save();return 0
    except Exception as error:
        tb=error.__traceback__
        while tb.tb_next is not None:tb=tb.tb_next
        r.update(status='failed-or-incomplete',failure_class=type(error).__name__,failure_site={'file':pathlib.Path(tb.tb_frame.f_code.co_filename).name,'line':tb.tb_lineno});save();return 1
    finally:
        if current is not None and current.poll() is None:current.kill();current.wait(timeout=5)
        # Independent dispatcher owns exact-unit scope cleanup; retain all stores.
        save()

def reconcile(run,body,manager):
    m=helpers();harness_pids=[body['pid']]
    assert all(type(pid) is int and pid>0 for pid in harness_pids)
    manager=pathlib.Path(manager)
    assert manager==pathlib.Path(f'/sys/fs/cgroup/user.slice/user-{os.getuid()}.slice/user@{os.getuid()}.service')
    end=time.monotonic()+100;rows=[];unknown=[]
    def issue(phase,error):unknown.append({'phase':phase,'class':type(error).__name__})
    records=body['scopes'];assert len(records)<=8
    identities={row['unit']:{'invocation_id':row['identity']['invocation'],'control_group':row['identity']['cgroup']} for row in records if row.get('identity')}
    observed={row['unit']:[row['identity']['cgroup']] for row in records if row.get('identity')}
    def path(unit,value):
        assert isinstance(value,str) and value.startswith('/') and '..' not in pathlib.PurePosixPath(value).parts
        p=pathlib.Path('/sys/fs/cgroup')/value.lstrip('/')
        assert p.is_relative_to(manager) and p.name==unit
        return p
    for entry in records:
        item={'queries':[]};rows.append(item)
        try:
            record=dict(entry,harness_pid=body['pid'],launcher_pid=entry['wrapper_pid'],start_ticks=entry['wrapper_start']);unit=record['unit'];item['inventory']=record
            assert record['harness_pid'] in harness_pids and re.fullmatch(r'oojuro-record-context-(before|after)-'+str(record['harness_pid'])+r'-[0-9]+\.scope',unit)
            def query():
                left=end-time.monotonic();assert left>0
                args=['/usr/bin/systemctl','--user','show',unit,'--property=LoadState','--property=ActiveState','--property=ControlGroup','--property=InvocationID']
                q=subprocess.run(args,capture_output=True,text=True,timeout=min(5,left))
                item['queries'].append({'command':args,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr})
                m.save(run/'scope-reconciliation.json',{'rows':rows,'unknown':unknown})
                v=dict(x.split('=',1) for x in q.stdout.splitlines() if '=' in x)
                if v.get('ControlGroup'):
                    actual=v['ControlGroup'];path(unit,actual)
                    if actual not in observed.setdefault(unit,[]):observed[unit].append(actual);m.save(run/'scope-observations.json',observed)
                return v
            v=query()
            if v.get('ActiveState') in ['active','activating','deactivating','failed']:
                if unit not in identities:
                    assert m.ticks(record['launcher_pid'])==record['start_ticks']
                    assert pathlib.Path(f"/proc/{record['launcher_pid']}/cgroup").read_text().strip()=='0::'+v['ControlGroup']
                    assert re.fullmatch('[0-9a-f]{32}',v['InvocationID'])
                    identities[unit]={'invocation_id':v['InvocationID'],'control_group':v['ControlGroup']}
                    m.save(run/'scope-identities.json',identities)
                for action in [['kill','--signal=KILL','--kill-whom=all',unit],['stop',unit]]:
                    v=query();identity=identities[unit]
                    if v.get('LoadState')=='not-found' or v.get('ActiveState')=='inactive':break
                    assert v['InvocationID']==identity['invocation_id'] and v['ControlGroup']==identity['control_group']
                    left=end-time.monotonic();assert left>0
                    q=subprocess.run(['/usr/bin/systemctl','--user',*action],capture_output=True,text=True,timeout=min(5,left))
                    item.setdefault('termination',[]).append({'action':action,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr})
                    m.save(run/'scope-reconciliation.json',{'rows':rows,'unknown':unknown})
            until=min(end,time.monotonic()+5)
            while True:
                v=query();dead=v.get('LoadState')=='not-found' or v.get('ActiveState')=='inactive'
                actual_absent=all(not path(unit,p).exists() for p in observed.get(unit,[]))
                named=[];count=0
                def failed(error):raise error
                if dead:
                    for parent,dirs,files in os.walk(manager,onerror=failed):
                        count+=1;assert count<=4096 and time.monotonic()<end
                        if unit in dirs:named.append(str(pathlib.Path(parent)/unit))
                if dead and actual_absent and not named and m.ticks(record['launcher_pid'])!=record['start_ticks']:break
                assert time.monotonic()<until;time.sleep(.05)
            item.update(status='reconciled',actual_paths_absent=actual_absent,exact_named_paths_remaining=named,original_pid_identity_absent=True)
        except Exception as error:item['status']='unknown';issue('scope',error)
    result={'rows':rows,'unknown':unknown,'manager_hierarchy':str(manager)}
    m.save(run/'scope-reconciliation.json',result);return result

if __name__=='__main__':raise SystemExit(main())
