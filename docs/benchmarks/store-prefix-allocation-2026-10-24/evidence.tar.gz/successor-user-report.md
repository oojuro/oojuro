# Store prefix allocation with explicit full-read preallocation

**Status:** all three focused checks and the fixed 32-process comparison passed. C and the coordinator independently verified all reports, current closed inventories and cleanup.

This successor keeps the prefix allocation and retained-capacity accounting change, then preallocates the complete output once when the caller explicitly requests a full decode (`need=None`). It adds no dependency, format, CRC, decryption or digest change. The comparison is against retained PR88, so it measures the combined changes and does not isolate this final expression.

## Fixed optimized API diagnostic

The same helper and 128 × 128 KiB synthetic originals were used in 32 four-row frames, with a 1 MiB cache. Four alternating paired rounds ran separate Store/RunReader prefix and full-scan processes. Store used sealed Zstd; RunReader used plaintext Zstd. One common closed ciphertext template was copied exactly within this campaign. AEAD ciphertext may differ between campaigns.

Medians of four samples; elapsed stages include byte hashing:

| Case | Stage RSS before → after (KiB) | Stage time before → after (ms) |
|---|---:|---:|
| Store early row | 9,320 → 5,908 | 2.989 → 1.536 |
| RunReader early row | 8,546 → 5,440 | 3.054 → 1.899 |
| Store full scan | 6,200 → 6,262 | 5.809 → 5.528 |
| RunReader full scan | 5,674 → 5,680 | 8.466 → 8.551 |

Early-row RSS improved in all four pairs. Whole-probe peak RSS stayed around 18.4–18.6 MiB, with no meaningful overall peak reduction. The short-prefix body-capacity reduction is largely reserved virtual capacity: Store 16,781,092 → 7,752 B and RunReader 16,778,240 → 3,072 B. Prefix RSS remains nearly neutral.

Full scans remain mixed. Two Store pairs and three RunReader pairs were slower; RunReader median time worsened. Current phase RSS, cumulative HWM, whole-probe peak RSS and helper-plus-probe cgroup peak are distinct accounting scopes.

## Every full-scan pair

| Round/order | Store before → after (ms) | RunReader before → after (ms) |
|---|---:|---:|
| 0/before/after | 5.915 → 6.085 | 8.094 → 8.464 |
| 1/after/before | 5.863 → 5.523 | 8.531 → 9.625 |
| 2/before/after | 5.388 → 5.534 | 8.401 → 8.638 |
| 3/after/before | 5.755 → 5.494 | 8.783 → 8.416 |

## Preserved first campaign

The earlier prefix/accounting candidate remains separate evidence: Store full-scan median 5.573 → 5.984 ms and RunReader 8.591 → 8.831 ms, with neutral whole-probe peak RSS. This successor campaign does not replace or erase those adverse results. No favorable repeat or changed input was used.

## Verification and limits

All 128 originals and every Store record field were checked after each process. All phase/original digests matched; the template plus 32 copies remained byte/mode/block identical before and after. All 70 observed process identities and 34 actual/named cgroups are absent. Raw reports and both campaigns remain retained.

The optimized normal Store library, library test, Run and encrypted test artifacts were freshly compiled after a package-only clean. Exactly three focused checks passed once. The earlier shared-target reuse refusal and its fingerprint evidence remain preserved.

The helper reads and checks every compressed frame before timed stages. This is warm, fits RAM, highly compressible synthetic API evidence with four samples per case. It establishes no native RecordLog CLI, hosted, OS-cold, tail-latency, general performance or cost gain. All 32 reports and accounting categories are retained in the companion JSON.
