#!/usr/bin/python3 -I
"""Build only: real production Record CLI debug artifacts and exact wire-budget checks."""
import argparse, hashlib, json, os, pathlib, re, resource, shutil, signal, subprocess, tempfile, time
W = pathlib.Path(__file__).resolve().parents[2]
OUT = W / "work/record-counted-search-bounds-20261024"
TOOLS = W / "work/public-ci-rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin"
SOURCES = {"before":("oojuro-core-streamed-records","7261a55d9230596470b2f64aeed4175fbe358aba"), "after":("oojuro-record-counted-search-bounds","09b0fbd943625a031698fb52cd574b006b31786a")}
def sha(p):
    with pathlib.Path(p).open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
def main():
    label=argparse.ArgumentParser();label.add_argument("label",choices=SOURCES);a=label.parse_args()
    tree,commit=SOURCES[a.label];root=W/"work"/tree;out=OUT/a.label
    out.mkdir(mode=0o700) # never overwrite an uncertain prior attempt
    cgtext=pathlib.Path("/proc/self/cgroup").read_text().strip()
    cg=pathlib.Path("/sys/fs/cgroup")/cgtext.split("0::",1)[1].lstrip("/")
    # Preserve raw actual properties before asserting any observed cap.
    observed=subprocess.run(["/usr/bin/systemctl","--user","show",cg.name,"--property=ActiveState","--property=InvocationID","--property=ControlGroup","--property=MainPID","--property=MemoryMax","--property=MemorySwapMax","--property=TasksMax","--property=RuntimeMaxUSec","--property=TimeoutStopUSec","--property=KillMode","--property=LimitCORE"],capture_output=True,text=True,timeout=5)
    (out/"live-properties.json").write_text(json.dumps({"returncode":observed.returncode,"stdout":observed.stdout,"stderr":observed.stderr,"pid":os.getpid(),"cgroup":str(cg)},indent=2)+"\n")
    assert observed.returncode==0
    assert re.fullmatch(r"0::/user.slice/user-1000.slice/user@1000.service/app.slice/oojuro-counted-search-build-"+a.label+r"-[0-9a-f]{16}\.service",cgtext)
    fields=dict(line.split("=",1) for line in observed.stdout.splitlines() if "=" in line)
    assert fields["ActiveState"]=="active" and fields["MainPID"]==str(os.getpid())
    assert fields["ControlGroup"]==cgtext.split("0::",1)[1]
    assert re.fullmatch("[0-9a-f]{32}",fields["InvocationID"])
    assert all(fields[k]==v for k,v in {"MemoryMax":str(6<<30),"MemorySwapMax":"0","TasksMax":"512","RuntimeMaxUSec":"20min","TimeoutStopUSec":"5s","KillMode":"control-group","LimitCORE":"0"}.items())
    assert set((cg/"cgroup.procs").read_text().split())=={str(os.getpid())}
    assert (cg/"memory.max").read_text().strip()==str(6<<30)
    assert (cg/"pids.max").read_text().strip()=="512"
    assert (cg/"memory.swap.max").read_text().strip()=="0"
    assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip()==commit
    assert not subprocess.check_output(["git","status","--porcelain"],cwd=root,text=True)
    scratch=pathlib.Path(tempfile.mkdtemp(prefix="ojcounted-",dir="/var/tmp"));scratch.chmod(0o700)
    target=OUT/("target-"+a.label);assert not target.exists()
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    env=os.environ.copy()
    for key in list(env):
        if key.startswith(("CARGO_PROFILE_","CARGO_TARGET_")) or key in ["CARGO_ENCODED_RUSTFLAGS","RUSTC_WRAPPER","RUSTC_WORKSPACE_WRAPPER","RUSTC_BOOTSTRAP","RUSTUP_TOOLCHAIN","RUSTUP_HOME","CARGO_BUILD_TARGET"]:
            env.pop(key,None)
    env.update(PATH=str(TOOLS)+":"+str(W/"work/portable-key-build")+":<HOME>/.cargo/bin:"+env["PATH"],
               RUSTC=str(TOOLS/"rustc"),RUSTDOC=str(TOOLS/"rustdoc"),CC=str(W/"work/portable-key-build/cc"),
               CXX=str(W/"work/portable-key-build/c++"),CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER=str(W/"work/portable-key-build/cc"),
               RUSTFLAGS="-C target-cpu=x86-64",CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS="2",CARGO_NET_OFFLINE="true",
               CARGO_TERM_COLOR="never",LC_ALL="C",TMPDIR=str(scratch),AWS_EC2_METADATA_DISABLED="true")
    command=[str(TOOLS/"cargo"),"build","--offline","--locked","--target","x86_64-unknown-linux-gnu","-j","2",
             "-p","oojuro","--bin","oojuro-native","--no-default-features","--message-format=json-render-diagnostics"]
    receipt={"status":"started","source":commit,"worktree":str(root),"label":a.label,"command":command,"profile":"debug",
             "target":"x86_64-unknown-linux-gnu","requested_features":[],"cgroup":str(cg),"cgroup_text":cgtext,
             "runtime_seconds":1200,"memory_bytes":6<<30,"tasks":512,"core_limit":0,"scratch":str(scratch),
             "environment":{k:env[k] for k in ["RUSTC","RUSTDOC","CC","CXX","RUSTFLAGS","CARGO_TARGET_DIR","CARGO_BUILD_JOBS","CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER"]},
             "lock_sha256":sha(root/"Cargo.lock"),"driver_sha256":sha(__file__)}
    def save():(out/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
    proc=None;code=1;started=time.monotonic()
    try:
        receipt["tools"]={name:{"path":str(TOOLS/name),"sha256":sha(TOOLS/name),
                         "version":subprocess.check_output([str(TOOLS/name),"-vV"],env=env,text=True)} for name in ["cargo","rustc"]}
        assert receipt["tools"]["rustc"]["version"].startswith("rustc 1.99.1 ")
        receipt["wrappers"]={name:sha(W/"work/portable-key-build"/name) for name in ["cc","c++"]}
        save()
        with (out/"cargo.jsonl").open("xb") as messages,(out/"cargo.stderr").open("xb") as errors:
            proc=subprocess.Popen(command,cwd=root,env=env,stdout=messages,stderr=errors)
            try:code=proc.wait(timeout=1130)
            except subprocess.TimeoutExpired:receipt["timeout"]=True;raise
        receipt["cargo_exit"]=code;save();assert code==0
        messages=[json.loads(line) for line in (out/"cargo.jsonl").read_text().splitlines() if line.startswith("{")]
        artifacts=[m for m in messages if m.get("reason")=="compiler-artifact"]
        selected=[m for m in artifacts if m["target"]["src_path"] in [str(root/"crates/oojuro/src/lib.rs"),str(root/"crates/oojuro/src/bin/oojuro-native.rs")]]
        assert len(selected)==2 and all(m["fresh"] is False and m["features"]==[] and m["profile"]["opt_level"]=="0" and m["profile"]["test"] is False for m in selected)
        binary=next(m for m in selected if m["executable"] is not None)
        frozen=out/"oojuro-native";shutil.copyfile(binary["executable"],frozen);frozen.chmod(0o500)
        receipt["selected_artifacts"]=selected
        receipt["built_feature_inventory"]=[{"package":m["package_id"],"features":m["features"],"target":m["target"]["name"]} for m in artifacts]
        assert not any("aws-" in m["package_id"] or "aws_" in m["package_id"] or "tantivy" in m["package_id"] or "postgres" in m["package_id"] for m in artifacts)
        engine=[m for m in artifacts if m["target"]["src_path"]==str(root/"crates/oojuro-engine/src/lib.rs")]
        assert len(engine)==1 and engine[0]["features"]==[] and engine[0]["fresh"] is False and engine[0]["profile"]["opt_level"]=="0" and engine[0]["profile"]["test"] is False
        receipt["normal_engine_artifact"]=engine[0]
        header=subprocess.check_output(["readelf","-h",str(frozen)],text=True);assert "Advanced Micro Devices X86-64" in header
        versions=subprocess.check_output(["readelf","--version-info",str(frozen)],text=True)
        glibc=sorted(set(re.findall(r"GLIBC_([0-9.]+)",versions)),key=lambda v:tuple(map(int,v.split("."))))
        assert glibc and tuple(map(int,glibc[-1].split(".")))<=(2,39)
        receipt["binary"]={"path":str(frozen),"sha256":sha(frozen),"bytes":frozen.stat().st_size,"source":binary["target"]["src_path"],
                           "fresh":False,"features":binary["features"],"glibc_versions":glibc,"readelf_header":header,
                           "dynamic_section":subprocess.check_output(["readelf","-d",str(frozen)],text=True)}
        treecmd=[str(TOOLS/"cargo"),"tree","--offline","--locked","--target","x86_64-unknown-linux-gnu","-p","oojuro","--no-default-features","-e","features"]
        with (out/"features.txt").open("xb") as f:subprocess.run(treecmd,cwd=root,env=env,stdout=f,stderr=subprocess.PIPE,check=True,timeout=30)
        selectors=[]
        if a.label=="after":
            for name in ["record_search_exact_wire_budget_includes_large_escaped_originals_and_metadata",
                         "counted_json_preserves_exact_escaped_wire_bounds",
                         "record_time_snapshot_pages_scope_fork_reopen_and_output_bounds"]:
                selectors.append((name,"oojuro-engine",None,"record::tests::"+name,1,True,None))
            for name in ["ranked_exact_wire_budget_counts_receipts_deltas_and_escaped_originals",
                         "off_never_calls_plugin_and_all_skipped_preserves_ids_bits_and_f2"]:
                selectors.append((name,"oojuro-engine",None,"record::ranking::tests::"+name,1,True,None))
            selectors.append(("actual-context","oojuro",None,"explicit_native_context_measures_whole_original_and_honestly_labels_estimate",1,True,"native_record_context"))
        receipt["tests"]=[]
        for name,package,features,selector,expected,exact,integration in selectors:
            testcmd=[str(TOOLS/"cargo"),"test","--offline","--locked","--target","x86_64-unknown-linux-gnu","-j","2",
                     "-p",package,"--no-default-features","--message-format=json-render-diagnostics"]
            testcmd += ["--test",integration] if integration else ["--lib"]
            if features is not None:testcmd += ["--features",features]
            testcmd += [selector,"--"]
            if exact:testcmd.append("--exact")
            testcmd.append("--test-threads=1")
            item={"name":name,"command":testcmd};receipt["tests"].append(item);save()
            remaining=1130-(time.monotonic()-started);assert remaining>0
            with (out/(name+".stdout")).open("xb") as stdout,(out/(name+".stderr")).open("xb") as stderr:
                proc=subprocess.Popen(testcmd,cwd=root,env=env,stdout=stdout,stderr=stderr)
                item["exit"]=proc.wait(timeout=min(300,remaining))
            counts=re.findall(r"test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;",(out/(name+".stdout")).read_text())
            item["counts"]=counts;save()
            assert item["exit"]==0 and counts==[("ok",str(expected),"0","0")]
            if not integration and "libtest" not in receipt:
                messages=[json.loads(line) for line in (out/(name+".stdout")).read_text().splitlines() if line.startswith("{")]
                tests=[m for m in messages if m.get("reason")=="compiler-artifact" and m["target"]["src_path"]==str(root/"crates/oojuro-engine/src/lib.rs") and m["profile"]["test"] is True and m.get("executable")]
                assert len(tests)==1 and tests[0]["fresh"] is False and tests[0]["features"]==[] and tests[0]["profile"]["opt_level"]=="0"
                receipt["libtest"]={"artifact":tests[0],"sha256":sha(tests[0]["executable"]),"source":commit};save()
        receipt["final_worktree_status"]=subprocess.check_output(["git","status","--porcelain"],cwd=root,text=True,timeout=5)
        assert not receipt["final_worktree_status"]
        receipt["final_source"]=subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True,timeout=5).strip()
        assert receipt["final_source"]==commit
        receipt["status"]="debug-native-cli-frozen-focused-tests-passed";code=0
    except Exception as error:receipt["failure_class"]=type(error).__name__;receipt["status"]="build-or-qualification-refused";code=1
    finally:
        # Signal only the still-owned Popen child. Never signal PIDs merely
        # enumerated from cgroup.procs: they may be reaped/reused between reads.
        if proc is not None and proc.poll() is None:
            try:
                proc.kill()
                proc.wait(timeout=5)
            except Exception as error:
                receipt["owned_child_cleanup_error_class"]=type(error).__name__
        remaining={int(p) for p in (cg/"cgroup.procs").read_text().split()}-{os.getpid()}
        receipt["remaining_descendants"]=sorted(remaining);receipt["cleanup_unknown"]=bool(remaining)
        if not remaining:
            try:shutil.rmtree(scratch)
            except OSError as error:receipt["cleanup_unknown"]=True;receipt["cleanup_error_class"]=type(error).__name__
        receipt["scratch_removed"]=not scratch.exists()
        if receipt["cleanup_unknown"] or not receipt["scratch_removed"]:code=1;receipt["status"]="cleanup-incomplete"
        receipt["wall_seconds"]=round(time.monotonic()-started,3)
        receipt["closed_logs"]={p.name:{"bytes":p.stat().st_size,"sha256":sha(p)} for p in out.iterdir() if p.is_file() and p.name!="receipt.json"}
        save()
    print(json.dumps({"label":a.label,"status":receipt["status"],"receipt":str(out/"receipt.json")}),flush=True)
    return code
if __name__=="__main__":raise SystemExit(main())

