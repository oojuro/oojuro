#!/usr/bin/python3 -I
"""Only the corrected ranked test and two previously unrun selectors."""
import hashlib,json,os,pathlib,re,shutil,subprocess,tempfile,time
W=pathlib.Path(__file__).resolve().parents[2]
OUT=W/'work/record-counted-search-bounds-20261024'
ROOT=W/'work/oojuro-record-counted-search-bounds'
SOURCE='631c19cd1ecfe9ecc7ee99379c8ef9e5c49896ce'
RUNTIME='09b0fbd943625a031698fb52cd574b006b31786a'
TOOLS=W/'work/public-ci-rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin'
TARGET=OUT/'target-after'
RUN=OUT/'checks-continuation-1'

def sha(p):
    with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def save(p,v):
    tmp=p.with_name(p.name+'.pending');fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'w') as f:json.dump(v,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    os.replace(tmp,p);fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)

def main():
    os.umask(0o077);RUN.mkdir(mode=0o700)
    receipt={'status':'running','phase':'preflight','tests':[],'runtime':RUNTIME,'source':SOURCE};proc=None;scratch=None;cg=None;code=1;started=time.monotonic()
    def persist():save(RUN/'receipt.json',receipt)
    def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True,timeout=5)
    persist()
    try:
        full=git('rev-parse',SOURCE).strip();assert git('rev-parse','HEAD').strip()==full and not git('status','--porcelain')
        assert git('diff','--name-only',RUNTIME,full).splitlines()==['crates/oojuro-engine/src/record/ranking_tests.rs']
        receipt['source']=full;receipt['runtime_equivalence']='Only ranking_tests.rs differs from qualified09b0; all production/manifests unchanged'
        assert TARGET.is_dir()
        expected={'before':'42d1d4ba03c921d584b7ad54de1365d3fabbe472067c0c859965a3965dc78eb7','after':'cd270843f75412ce77ac70ff13296d7aeb3a1ad4197e56a8e3051dafca8f2339'}
        for label,digest in expected.items():assert sha(OUT/label/'oojuro-native')==digest
        receipt['frozen_cli_sha256']=expected
        cgtext=pathlib.Path('/proc/self/cgroup').read_text().strip();cg=pathlib.Path('/sys/fs/cgroup')/cgtext.split('0::',1)[1].lstrip('/')
        q=subprocess.run(['/usr/bin/systemctl','--user','show',cg.name,'--property=ActiveState','--property=MainPID','--property=InvocationID','--property=ControlGroup','--property=MemoryMax','--property=MemorySwapMax','--property=TasksMax','--property=RuntimeMaxUSec','--property=TimeoutStopUSec','--property=KillMode','--property=LimitCORE'],capture_output=True,text=True,timeout=5)
        receipt['actual_properties']={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr};receipt['cgroup']=str(cg);persist()
        fields=dict(s.split('=',1) for s in q.stdout.splitlines() if '=' in s)
        assert q.returncode==0 and fields['ActiveState']=='active' and fields['MainPID']==str(os.getpid()) and fields['ControlGroup']==cgtext.split('0::',1)[1]
        assert re.fullmatch('oojuro-counted-search-checks-[0-9a-f]{16}\\.service',cg.name)
        assert all(fields[k]==v for k,v in {'MemoryMax':str(6<<30),'MemorySwapMax':'0','TasksMax':'512','RuntimeMaxUSec':'10min','TimeoutStopUSec':'5s','KillMode':'control-group','LimitCORE':'0'}.items())
        assert set((cg/'cgroup.procs').read_text().split())=={str(os.getpid())}
        scratch=pathlib.Path(tempfile.mkdtemp(prefix='ojcountchecks-',dir='/var/tmp'));scratch.chmod(0o700);receipt['scratch']=str(scratch)
        env=os.environ.copy()
        for key in list(env):
            if key.startswith(('CARGO_PROFILE_','CARGO_TARGET_')) or key in ['CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTC_BOOTSTRAP','RUSTUP_TOOLCHAIN','RUSTUP_HOME','CARGO_BUILD_TARGET']:env.pop(key,None)
        env.update(PATH=str(TOOLS)+':'+str(W/'work/portable-key-build')+':<HOME>/.cargo/bin:'+env['PATH'],RUSTC=str(TOOLS/'rustc'),RUSTDOC=str(TOOLS/'rustdoc'),CC=str(W/'work/portable-key-build/cc'),CXX=str(W/'work/portable-key-build/c++'),CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER=str(W/'work/portable-key-build/cc'),RUSTFLAGS='-C target-cpu=x86-64',CARGO_TARGET_DIR=str(TARGET),CARGO_BUILD_JOBS='2',CARGO_NET_OFFLINE='true',CARGO_TERM_COLOR='never',LC_ALL='C',TMPDIR=str(scratch),AWS_EC2_METADATA_DISABLED='true')
        receipt['environment']={k:env[k] for k in ['RUSTC','RUSTDOC','CC','CXX','CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER','RUSTFLAGS','CARGO_TARGET_DIR','CARGO_BUILD_JOBS']}
        receipt['toolchain']={name:{'path':str(TOOLS/name),'sha256':sha(TOOLS/name),'version':subprocess.check_output([str(TOOLS/name),'-vV'],env=env,text=True,timeout=5)} for name in ['cargo','rustc']}
        assert receipt['toolchain']['rustc']['version'].startswith('rustc 1.99.1 ');persist()
        selectors=[('ranked-corrected','oojuro-engine',None,'record::ranking::tests::ranked_exact_wire_budget_counts_receipts_deltas_and_escaped_originals'),('ranked-parity','oojuro-engine',None,'record::ranking::tests::off_never_calls_plugin_and_all_skipped_preserves_ids_bits_and_f2'),('actual-context','oojuro','native_record_context','explicit_native_context_measures_whole_original_and_honestly_labels_estimate')]
        for label,package,integration,selector in selectors:
            receipt['phase']=label;cmd=[str(TOOLS/'cargo'),'test','--offline','--locked','--target','x86_64-unknown-linux-gnu','-j','2','-p',package,'--no-default-features','--message-format=json-render-diagnostics']
            cmd+=['--test',integration] if integration else ['--lib'];cmd+=[selector,'--','--exact','--test-threads=1']
            item={'name':label,'command':cmd};receipt['tests'].append(item);persist()
            with (RUN/(label+'.stdout')).open('xb') as out,(RUN/(label+'.stderr')).open('xb') as err:
                proc=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=out,stderr=err);item['pid']=proc.pid;persist();left=530-(time.monotonic()-started);assert left>0;item['exit']=proc.wait(timeout=left)
            output=(RUN/(label+'.stdout')).read_text();counts=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',output);item['counts']=counts;persist()
            assert item['exit']==0 and counts==[('ok','1','0','0')]
            if label=='ranked-corrected':
                messages=[json.loads(s) for s in output.splitlines() if s.startswith('{')]
                found=[v for v in messages if v.get('reason')=='compiler-artifact' and v['target']['src_path']==str(ROOT/'crates/oojuro-engine/src/lib.rs') and v['profile']['test'] is True and v.get('executable')]
                assert len(found)==1 and found[0]['fresh'] is False and found[0]['features']==[] and found[0]['profile']['opt_level']=='0'
                receipt['libtest']={'artifact':found[0],'sha256':sha(found[0]['executable'])};persist()
        assert not git('status','--porcelain') and git('rev-parse','HEAD').strip()==full
        for label,digest in expected.items():assert sha(OUT/label/'oojuro-native')==digest
        receipt.update(status='three-selectors-passed-cli-runtime-unchanged',phase='terminal');code=0
    except Exception as error:
        tb=error.__traceback__
        while tb.tb_next is not None:tb=tb.tb_next
        receipt.update(status='failed-or-incomplete',failure_class=type(error).__name__,failure_site={'file':pathlib.Path(tb.tb_frame.f_code.co_filename).name,'line':tb.tb_lineno})
    finally:
        if proc is not None and proc.poll() is None:
            proc.kill()
            try:proc.wait(timeout=5)
            except subprocess.TimeoutExpired:receipt['cleanup_unknown']=True
        remaining={int(p) for p in (cg/'cgroup.procs').read_text().split()}-{os.getpid()} if cg is not None else set()
        receipt['remaining_descendants']=sorted(remaining);receipt['cleanup_unknown']=receipt.get('cleanup_unknown',False) or bool(remaining)
        if scratch is not None and not remaining:
            try:shutil.rmtree(scratch)
            except OSError as error:receipt.update(cleanup_unknown=True,cleanup_error_class=type(error).__name__)
        receipt['scratch_removed']=scratch is None or not scratch.exists()
        if receipt['cleanup_unknown'] or not receipt['scratch_removed']:code=1
        receipt['wall_seconds']=time.monotonic()-started;receipt['exit']=code;persist()
    print(json.dumps({'exit':code,'receipt':str(RUN/'receipt.json')}),flush=True);return code

if __name__=='__main__':raise SystemExit(main())
