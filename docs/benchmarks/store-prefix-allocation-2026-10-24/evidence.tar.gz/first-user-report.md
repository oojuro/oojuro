# Store prefix allocation and cache accounting

**Scope:** one fixed, optimized warm API diagnostic; independently qualified by the coordinator. All 13 focused checks and 32 measured processes passed. This does not measure native RecordLog CLI or hosted performance.

The change allocates only a requested Zstd prefix and charges the body plus all retained metadata vector capacities. CRC, decryption, full-body digest checks, on-disk formats and dependencies are unchanged. Both arms read the same 128 × 128 KiB originals in 32 four-row frames, with a 1 MiB configured cache; Store is strictly sealed, while RunReader is plaintext.

## Retained cache capacity

| After 32 short prefixes | Before body capacity | After body capacity | After total known cache charge |
|---|---:|---:|---:|
| Store | 16,781,092 B | 7,752 B | 18,632 B |
| RunReader | 16,778,240 B | 3,072 B | 13,952 B |

Capacity is reserved allocation, not resident RAM. Prefix RSS was nearly neutral because untouched zero pages need not be resident. Decoder/dictionary state, Arc/allocator overhead, cache containers and caller-held frames are outside this cache budget.

## Actual early-row and full-scan results

Medians of four paired samples; stage times include returned-byte hashing. Each full-scan case used its own fresh process.

| API case | Stage RSS before → after (KiB) | Stage elapsed before → after (ms) |
|---|---:|---:|
| Store early row | 9,362 → 5,944 | 2.892 → 1.770 |
| RunReader early row | 8,512 → 5,524 | 3.233 → 1.894 |
| Store full scan | 6,270 → 6,292 | 5.573 → 5.984 |
| RunReader full scan | 5,688 → 5,718 | 8.591 → 8.831 |

Early-row RSS improved in every pair. Full scans were slower in three of four Store pairs and two of four RunReader pairs; both median scan times worsened. Whole-probe peak RSS stayed around 18.5 MiB, so these results establish no meaningful whole-probe peak reduction. Current RSS, cumulative HWM, child peak RSS and whole-helper cgroup peaks are separate measurements.

### All full-scan pairs

| Round/order | Store scan before → after (ms) | RunReader scan before → after (ms) |
|---|---:|---:|
| 0/before/after | 5.633 → 5.933 | 8.580 → 9.718 |
| 1/after/before | 5.514 → 6.034 | 8.597 → 8.303 |
| 2/before/after | 5.856 → 5.387 | 8.586 → 8.960 |
| 3/after/before | 5.374 → 6.285 | 9.333 → 8.703 |

## Verification and limits

All 128 originals and every Store record field were checked after each case. All phase/original hashes matched per API; 33 closed template/copy inventory pairs remained byte/mode/block identical. All 72 observed process identities and 34 actual/named cgroups are absent; fixtures remain retained for review.

The helper reads/checks compressed frames before timed stages, and Store opens verify hot frames. This is a warm, fits-RAM, highly compressible synthetic case with four samples per runtime/API: no OS-cold, tail, release-wide, hosted or cost conclusion.

The first candidate build was correctly refused when Cargo reused the baseline library. Its raw fingerprint evidence remains; a distinct candidate-only package clean produced fresh normal/library-test artifacts. No failed workload was retried.

A tiny follow-up could restore single allocation for explicit full reads (`need=None`). A one-expression source successor is prepared but uncompiled and unmeasured. Full pair data, phase counters and all adverse results are in the companion JSON.
