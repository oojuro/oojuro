#!/usr/bin/python3 -I
"""Fixed32-row, eight-store actual production CLI durable append allocation diagnostic."""
import argparse,hashlib,importlib.util,json,math,os,pathlib,re,shutil,stat,subprocess,time
BASE=pathlib.Path(__file__).resolve().parent
W=BASE.parents[2]
OUT=BASE.parent
RUN=OUT/'comparison-attempt-1'
STAGE=pathlib.Path('<FIXTURE>')
ARTIFACTS={'before':W/'work/native-record-borrowed-text-20261024/build-attempt-2/candidate/oojuro-native','after':OUT/'build-attempt-1/candidate/oojuro-native'}
SHAS={'before':'71754eef61c9fbdcc36ede784c873ffe15a96350b44c413d4d4bfba0240ce8c6','after':'1aaf67d50329c2be09f742cd79584750a9b9e0c89e96a4a808b407323a8c10e8'}
COMMON=W/'work/postgres-record-comparison-20261024/controller/run-comparison.py'
COMMON_SHA='b84a0f440c0ef4aafb0b019313f27806bf9166acceb7164459a8950b143b01bc'

def sha(p):
    with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def helpers():
    assert sha(COMMON)==COMMON_SHA
    spec=importlib.util.spec_from_file_location('qualified_inventory',COMMON);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main():
    p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');a=p.parse_args();assert a.execute
    os.umask(0o077);m=helpers()
    # Pending artifacts refuse BEFORE creating fixtures or launching any CLI.
    assert all(re.fullmatch('[0-9a-f]{64}',v) for v in SHAS.values())
    RUN.mkdir(mode=0o700);STAGE.mkdir(mode=0o700)
    r={'status':'running','pid':os.getpid(),'start_ticks':m.ticks(os.getpid()),'phase':'preflight','arms':[],'scopes':[],'observed':{},'source_runtime':'cd46c17f36b176d75a0587df035a4266abe6fbb0','control_runtime':'d6b1f94a0b39a529ceeff1dc7d198d4e0132315e','scope':'actual opt0 native Record CLI durable append allocation diagnostic; no release/hosted/general latency claim'}
    def save():m.save(RUN/'receipt.json',r)
    save();end=time.monotonic()+780;current=None
    def remaining():v=end-time.monotonic();assert v>0;return v
    def cli(binary,root,command,args,cap=2<<20):
        nonlocal current
        current=subprocess.Popen([str(binary),command,'--root',str(root),*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        out,err=current.communicate(timeout=min(30,remaining()))
        assert len(out)<=cap and len(err)<=65536 and current.returncode==0
        return json.loads(out)
    def records(root):
        page=cli(ARTIFACTS['before'],root,'record-range',['--versions','all','--entries','33','--bytes','33554432'],cap=32<<20)
        assert set(page)=={'watermark','records','next'} and page['next'] is None
        mark=page['watermark'];assert set(mark)=={'schema','origin','identity','sequence','records','commitment'}
        seal=mark['commitment'];assert isinstance(seal,list) and 0<len(seal)<=256 and all(type(x) is int and 0<=x<=255 for x in seal)
        return sorted(page['records'],key=lambda x:x['id']),{k:mark[k] for k in ['schema','origin','identity','sequence','records']}
    def scope_query(unit):
        q=subprocess.run(['/usr/bin/systemctl','--user','show',unit,'--property=LoadState','--property=ActiveState','--property=InvocationID','--property=ControlGroup','--property=MemoryMax','--property=MemorySwapMax','--property=TasksMax','--property=RuntimeMaxUSec','--property=TimeoutStopUSec'],capture_output=True,text=True,timeout=min(5,remaining()))
        r.setdefault('scope_property_queries',[]).append({'unit':unit,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr});save()
        return dict(s.split('=',1) for s in q.stdout.splitlines() if '=' in s)
    def measure(binary,label,root,name,batch,input_path):
        nonlocal current
        folder=RUN/(name+f'-b{batch}');folder.mkdir(mode=0o700)
        control={'binary':str(binary),'binary_sha256':SHAS[label],'root':str(root),'input':str(input_path),'input_sha256':sha(input_path),'request':f'fixture-{batch}','stdout':str(folder/'append.stdout'),'stderr':str(folder/'append.stderr'),'result':str(folder/'result.json'),'ack':str(folder/'peak-read.ack')}
        m.save(folder/'control.json',control)
        unit=f'oojuro-record-append-{label}-{os.getpid()}-{time.monotonic_ns()}.scope'
        command=['/usr/bin/systemd-run','--user','--scope','--quiet','--collect','--unit='+unit,'--property=MemoryMax=3G','--property=MemorySwapMax=0','--property=TasksMax=512','--property=RuntimeMaxSec=120','--property=TimeoutStopSec=5','--','/usr/bin/python3','-I',str(BASE/'measure-one.py'),str(folder/'control.json')]
        row={'name':name,'batch':batch,'unit':unit,'command':command};r['scopes'].append(row);save()
        with (folder/'scope.stdout').open('xb') as out,(folder/'scope.stderr').open('xb') as err:
            current=subprocess.Popen(command,stdout=out,stderr=err);row.update(wrapper_pid=current.pid,wrapper_start=m.ticks(current.pid));save();cg=None;ack=False;deadline=time.monotonic()+min(140,remaining())
            while current.poll() is None:
                if cg is None:
                    fields=scope_query(unit)
                    if fields.get('ActiveState')=='active' and fields.get('ControlGroup'):
                        row['identity']={'invocation':fields['InvocationID'],'cgroup':fields['ControlGroup']};save()
                        assert re.fullmatch('[0-9a-f]{32}',fields['InvocationID']) and fields['ControlGroup'].endswith('/'+unit)
                        assert all(fields[k]==v for k,v in {'MemoryMax':str(3<<30),'MemorySwapMax':'0','TasksMax':'512','RuntimeMaxUSec':'2min','TimeoutStopUSec':'5s'}.items())
                        cg=pathlib.Path('/sys/fs/cgroup')/fields['ControlGroup'].lstrip('/')
                if cg is not None and cg.exists():
                    for f in cg.rglob('cgroup.procs'):
                        for token in f.read_text().split():
                            pid=int(token);start=m.ticks(pid)
                            if start:r['observed'].setdefault(f'{pid}:{start}',{'pid':pid,'start_ticks':start,'cgroup':str(f.parent)})
                    if not ack and (folder/'result.json').exists():
                        result=m.read_json(folder/'result.json');assert result['helper_cgroup']=='0::'+row['identity']['cgroup']
                        row['cgroup_memory_peak_bytes']=int((cg/'memory.peak').read_text());row['result']=result;save()
                        fd=os.open(folder/'peak-read.ack',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);os.close(fd);ack=True
                assert time.monotonic()<deadline;time.sleep(.02)
            row['scope_exit']=current.returncode;save();assert current.returncode==0 and ack
        fields=scope_query(unit);assert fields.get('LoadState')=='not-found' or fields.get('ActiveState')=='inactive'
        assert not cg.exists() and m.ticks(row['wrapper_pid'])!=row['wrapper_start'];row['cgroup_absent']=True
        raw=(folder/'append.stdout').read_bytes();assert len(raw)<=65536
        body=json.loads(raw);assert set(body)=={'ids','recorded_at','watermark'}
        assert body['ids']==list(range(batch*8+1,batch*8+9)) and len(body['recorded_at'])==8 and all(type(t) is int for t in body['recorded_at'])
        return row,body
    try:
        for label,p in ARTIFACTS.items():assert sha(p)==SHAS[label]
        candidate=m.read_json(OUT/'build-attempt-1/candidate/receipt.json')
        assert candidate['status']=='native-record-append-lifetimes-cli-frozen-6-checks-passed' and candidate['source']==r['source_runtime'] and len(candidate['tests'])==6 and all(t['exit']==0 and t['counts']==[['ok','1','0','0']] for t in candidate['tests'])
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W/'work/oojuro-native-record-append-lifetimes',text=True).strip()==r['source_runtime']
        assert not subprocess.check_output(['git','status','--porcelain'],cwd=W/'work/oojuro-native-record-append-lifetimes',text=True)
        r['phase']='fixture-create';save();template=STAGE/'template'
        cli(ARTIFACTS['before'],template,'record-setup',['--writer','synthetic-counted-search','--owner','1','--first-id','1','--adapter','synthetic-counted-search'])
        inputs=[{'agent_id':'synthetic-reported','parent_id':None,'valid_at':i+1,'kind':'explicit','tool':None,'status':None,'exit':None,'key':None,'text':'needle '+('\0'*131072) if i<31 else 'needle compact exact context','attrs':{},'indexed':True} for i in range(32)]
        paths=[]
        for batch in range(4):
            p=STAGE/f'input-{batch}.json';raw=json.dumps(inputs[batch*8:batch*8+8],ensure_ascii=False,separators=(',',':')).encode();assert len(raw)<32<<20
            p.write_bytes(raw);p.chmod(0o600);paths.append(p)
        empty,template_mark=records(template);assert empty==[] and template_mark['sequence']==0 and template_mark['records']==0
        template_before=m.inventory(template);m.save(RUN/'template-before.json',template_before)
        r['inputs']=[{'batch':i,'bytes':p.stat().st_size,'sha256':sha(p)} for i,p in enumerate(paths)]
        r['fixed_records']=32;r['fixed_text_bytes']=sum(len(v['text'].encode()) for v in inputs);save()
        for round_number,order in enumerate([['before','after'],['after','before'],['before','after'],['after','before']]):
            for label in order:
                r['phase']=f'round-{round_number}-{label}';save();name=f'r{round_number}-{label}';root=STAGE/name;shutil.copytree(template,root,symlinks=True)
                assert m.inventory_equal(template_before,m.inventory(root))
                # Identical empty-authority warming operation for both arms.
                got,mark=records(root);assert got==[] and mark==template_mark
                batches=[];acks=[]
                for batch,path in enumerate(paths):
                    row,ack=measure(ARTIFACTS[label],label,root,name,batch,path);acks.append(ack)
                    batches.append({'batch':batch,'records':8,'wall_seconds':row['result']['wall_seconds'],'cli_max_rss_kib':row['result']['cli_max_rss_kib'],'whole_scope_memory_peak_bytes':row['cgroup_memory_peak_bytes']})
                # All verification is OUTSIDE the four measured append processes.
                values,mark=records(root);assert len(values)==32 and [v['id'] for v in values]==list(range(1,33))
                assert {k:mark[k] for k in ['schema','origin','identity']}=={k:template_mark[k] for k in ['schema','origin','identity']} and mark['sequence']==4 and mark['records']==32
                assigned=[t for ack in acks for t in ack['recorded_at']];assert all(b>a for a,b in zip(assigned,assigned[1:]))
                for i,(got,want) in enumerate(zip(values,inputs)):
                    assert set(got)==set(want)|{'schema','id','writer','adapter','recorded_at'}
                    assert all(got[k]==want[k] for k in want) and got['schema']==1 and got['id']==i+1 and got['recorded_at']==assigned[i] and got['writer']=='synthetic-counted-search' and got['adapter']=='synthetic-counted-search'
                before=m.inventory(root);m.save(RUN/(name+'-before-verification.json'),before)
                for batch,path in enumerate(paths):assert cli(ARTIFACTS[label],root,'record-append',['--request',f'fixture-{batch}','--input',str(path),'--allow-unredacted-records'])==acks[batch]
                assert m.inventory(root)==before
                copy=STAGE/(name+'-reopen');shutil.copytree(root,copy,symlinks=True);copy_before=m.inventory(copy);assert m.inventory_equal(before,copy_before);m.save(RUN/(name+'-copy-before.json'),copy_before)
                reopened,reopened_mark=records(copy);assert reopened==values and reopened_mark==mark
                copy_after=m.inventory(copy);assert copy_after==copy_before;m.save(RUN/(name+'-copy-after.json'),copy_after)
                after=m.inventory(root);assert after==before;m.save(RUN/(name+'-after-verification.json'),after)
                r['arms'].append({'round':round_number,'label':label,'name':name,'batches':batches,'ack_records':32,'all_full_record_fields_equal':True,'exact_four_original_retries':True,'copied_reopen_full_fields_equal':True,'closed_source_unchanged':True,'full_records_sha256':hashlib.sha256(json.dumps(values,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'wall_seconds_sum':sum(b['wall_seconds'] for b in batches),'maximum_cli_rss_kib':max(b['cli_max_rss_kib'] for b in batches),'maximum_whole_scope_peak_bytes':max(b['whole_scope_memory_peak_bytes'] for b in batches)});save()
        template_after=m.inventory(template);assert template_after==template_before;m.save(RUN/'template-after.json',template_after)
        assert len(r['arms'])==8 and len(r['scopes'])==32 and all(m.ticks(v['pid'])!=v['start_ticks'] for v in r['observed'].values())
        r.update(status='passed',phase='terminal',template_unchanged=True,stage_retained=str(STAGE),no_release_speed_claim=True,no_cross_arm_recorded_clock_or_ciphertext_equality_claim=True);save();return 0
    except Exception as error:
        tb=error.__traceback__
        while tb.tb_next is not None:tb=tb.tb_next
        r.update(status='failed-or-incomplete',failure_class=type(error).__name__,failure_site={'file':pathlib.Path(tb.tb_frame.f_code.co_filename).name,'line':tb.tb_lineno});save();return 1
    finally:
        if current is not None and current.poll() is None:current.kill();current.wait(timeout=5)
        # Independent dispatcher owns exact-unit scope cleanup; retain all stores.
        save()

def reconcile(run,body,manager):
    m=helpers();harness_pids=[body['pid']]
    assert all(type(pid) is int and pid>0 for pid in harness_pids)
    manager=pathlib.Path(manager)
    assert manager==pathlib.Path(f'/sys/fs/cgroup/user.slice/user-{os.getuid()}.slice/user@{os.getuid()}.service')
    end=time.monotonic()+100;rows=[];unknown=[]
    def issue(phase,error):unknown.append({'phase':phase,'class':type(error).__name__})
    records=body['scopes'];assert len(records)<=32
    identities={row['unit']:{'invocation_id':row['identity']['invocation'],'control_group':row['identity']['cgroup']} for row in records if row.get('identity')}
    observed={row['unit']:[row['identity']['cgroup']] for row in records if row.get('identity')}
    def path(unit,value):
        assert isinstance(value,str) and value.startswith('/') and '..' not in pathlib.PurePosixPath(value).parts
        p=pathlib.Path('/sys/fs/cgroup')/value.lstrip('/')
        assert p.is_relative_to(manager) and p.name==unit
        return p
    for entry in records:
        item={'queries':[]};rows.append(item)
        try:
            record=dict(entry,harness_pid=body['pid'],launcher_pid=entry['wrapper_pid'],start_ticks=entry['wrapper_start']);unit=record['unit'];item['inventory']=record
            assert record['harness_pid'] in harness_pids and re.fullmatch(r'oojuro-record-append-(before|after)-'+str(record['harness_pid'])+r'-[0-9]+\.scope',unit)
            def query():
                left=end-time.monotonic();assert left>0
                args=['/usr/bin/systemctl','--user','show',unit,'--property=LoadState','--property=ActiveState','--property=ControlGroup','--property=InvocationID']
                q=subprocess.run(args,capture_output=True,text=True,timeout=min(5,left))
                item['queries'].append({'command':args,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr})
                m.save(run/'scope-reconciliation.json',{'rows':rows,'unknown':unknown})
                v=dict(x.split('=',1) for x in q.stdout.splitlines() if '=' in x)
                if v.get('ControlGroup'):
                    actual=v['ControlGroup'];path(unit,actual)
                    if actual not in observed.setdefault(unit,[]):observed[unit].append(actual);m.save(run/'scope-observations.json',observed)
                return v
            v=query()
            if v.get('ActiveState') in ['active','activating','deactivating','failed']:
                if unit not in identities:
                    assert m.ticks(record['launcher_pid'])==record['start_ticks']
                    assert pathlib.Path(f"/proc/{record['launcher_pid']}/cgroup").read_text().strip()=='0::'+v['ControlGroup']
                    assert re.fullmatch('[0-9a-f]{32}',v['InvocationID'])
                    identities[unit]={'invocation_id':v['InvocationID'],'control_group':v['ControlGroup']}
                    m.save(run/'scope-identities.json',identities)
                for action in [['kill','--signal=KILL','--kill-whom=all',unit],['stop',unit]]:
                    v=query();identity=identities[unit]
                    if v.get('LoadState')=='not-found' or v.get('ActiveState')=='inactive':break
                    assert v['InvocationID']==identity['invocation_id'] and v['ControlGroup']==identity['control_group']
                    left=end-time.monotonic();assert left>0
                    q=subprocess.run(['/usr/bin/systemctl','--user',*action],capture_output=True,text=True,timeout=min(5,left))
                    item.setdefault('termination',[]).append({'action':action,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr})
                    m.save(run/'scope-reconciliation.json',{'rows':rows,'unknown':unknown})
            until=min(end,time.monotonic()+5)
            while True:
                v=query();dead=v.get('LoadState')=='not-found' or v.get('ActiveState')=='inactive'
                actual_absent=all(not path(unit,p).exists() for p in observed.get(unit,[]))
                named=[];count=0
                def failed(error):raise error
                if dead:
                    for parent,dirs,files in os.walk(manager,onerror=failed):
                        count+=1;assert count<=4096 and time.monotonic()<end
                        if unit in dirs:named.append(str(pathlib.Path(parent)/unit))
                if dead and actual_absent and not named and m.ticks(record['launcher_pid'])!=record['start_ticks']:break
                assert time.monotonic()<until;time.sleep(.05)
            item.update(status='reconciled',actual_paths_absent=actual_absent,exact_named_paths_remaining=named,original_pid_identity_absent=True)
        except Exception as error:item['status']='unknown';issue('scope',error)
    result={'rows':rows,'unknown':unknown,'manager_hierarchy':str(manager)}
    m.save(run/'scope-reconciliation.json',result);return result

if __name__=='__main__':raise SystemExit(main())
