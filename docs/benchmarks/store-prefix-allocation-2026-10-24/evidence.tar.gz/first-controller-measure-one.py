#!/usr/bin/python3 -I
"""One fixed Store/RunReader test-helper invocation; hold scope alive for final peak readback."""
import hashlib,json,os,pathlib,resource,stat,subprocess,sys,time

def sha(p):
    with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def main():
    os.umask(0o077);assert len(sys.argv)==2
    fd=os.open(sys.argv[1],os.O_RDONLY|os.O_NOFOLLOW)
    with os.fdopen(fd,'rb') as f:
        meta=os.fstat(f.fileno());assert stat.S_ISREG(meta.st_mode) and meta.st_uid==os.getuid() and meta.st_nlink==1 and stat.S_IMODE(meta.st_mode)==0o600 and meta.st_size<8192;c=json.load(f)
    assert sha(c['binary'])==c['binary_sha256']
    assert resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss==0
    assert c['mode'] in ['prepare','store-prefix','store-full','run-prefix','run-full']
    root=pathlib.Path(c['root']);meta=root.lstat()
    assert root.is_absolute() and root.is_relative_to('/var/tmp') and root.resolve()==root
    assert stat.S_ISDIR(meta.st_mode) and meta.st_uid==os.getuid() and stat.S_IMODE(meta.st_mode)==0o700
    cmd=[c['binary'],'reader::cache_probe::fixed_store_run_cache_probe','--exact','--ignored','--test-threads=1','--nocapture']
    env=os.environ.copy()
    for k in list(env):
        if k.startswith(('OOJURO_CACHE_PROBE_', 'RUST_TEST_')):env.pop(k,None)
    env.update(OOJURO_CACHE_PROBE_DIR=c['root'],OOJURO_CACHE_PROBE_MODE=c['mode'])
    started=time.monotonic();child=None
    try:
        with open(c['stdout'],'xb') as out,open(c['stderr'],'xb') as err:
            child=subprocess.Popen(cmd,env=env,stdout=out,stderr=err)
            start_ticks=pathlib.Path(f'/proc/{child.pid}/stat').read_text().rsplit(')',1)[1].split()[19]
            code=child.wait(timeout=45)
        wall=time.monotonic()-started;usage=resource.getrusage(resource.RUSAGE_CHILDREN)
        assert code==0 and pathlib.Path(c['stdout']).stat().st_size<=1<<20 and pathlib.Path(c['stderr']).stat().st_size<=1<<20
        r={'command':cmd,'exit':code,'probe_pid':child.pid,'probe_start_ticks':start_ticks,'wall_seconds':wall,'probe_max_rss_kib':usage.ru_maxrss,'probe_user_seconds':usage.ru_utime,'probe_system_seconds':usage.ru_stime,'stdout_sha256':sha(c['stdout']),'stdout_bytes':pathlib.Path(c['stdout']).stat().st_size,'helper_pid':os.getpid(),'helper_cgroup':pathlib.Path('/proc/self/cgroup').read_text().strip()}
        path=pathlib.Path(c['result']);tmp=path.with_name(path.name+'.pending');fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,'w') as f:json.dump(r,f);f.write('\n');f.flush();os.fsync(f.fileno())
        os.replace(tmp,path);deadline=time.monotonic()+10
        while not pathlib.Path(c['ack']).exists():assert time.monotonic()<deadline;time.sleep(.02)
        return 0
    finally:
        if child is not None and child.poll() is None:child.kill();child.wait(timeout=5)

if __name__=='__main__':raise SystemExit(main())
