# Fixed query correction: actual native Record context allocation diagnostic

SOURCE ONLY. No command, process, test or measurement dispatched. Runtime09b0/frozen before42d1/aftercd27 unchanged; test-only631 retains qualified six selectors. No new build requested.

## Cause of retained attempt3

Attempt3 measured only its first baseline CLI (4.07065s,56,604KiB maximumRSS); it returned an empty additionalContext and the unchanged nonempty-context oracle failed. One measured scope, zero candidate arms, zero complete pairs. This is not comparative performance evidence. Attempts1–3, their partial stores and raw receipts remain untouched; root independently verified attempt3 ten process identities/two cgroups absent.

Actual source: lexical.rs139–192 appends EVERY native Record without legacy deduplication and stores token length/distinct scope. The31large originals each contribute one word; short `needle compact exact context` contributes four, so scope mass35. prepared.rs89–142 unions term postings (OR); scope_model is active; μ128 and64-record prior padding make the collection mass8192. prepared.rs185–251 computes the per-query penalty and gains. With the existing one-term query, short score is approximately−0.03212bits (literal prior/8193 normalization slightly perturb the shown approximation); context.rs261 rejects it at the unchanged minimum0. Large positive originals cannot fit65536context bytes. The previous plan's assertion that the short record was eligible was wrong.

For the fixed query `needle compact`, short gets an additional rare-term gain and scores approximately+0.27222bits; the large one-word records score approximately−0.01018bits. These numbers are source-formula approximations, NOT observed scorer output. prepared.rs255–256 scores ALL32 when k32>=rows32;307–328 creates/sorts/truncates hits WITHOUT rejecting negative bits. Therefore all32fullRecords still reach Search serialization and preserve the allocation stress. No text, ID, sample size or context filter is changed.

## Exact new campaign delta

Distinct controller/stage/run/unit: context-controller-attempt-4; <FIXTURE>/e4b926af; context-attempt-4; oojuro-native-context-comparison-e4b926af.service.

1. Change ONLY measured query `needle`→`needle compact` in measure-one.py. Preserve32texts/31large NUL originals/eight copies/fourABBA/k32/top-k1/tokens2500/context65536/minbits0/clock/DEBUG binaries/caps.
2. Before ANY measured scope, ONE actual baseline `record-search --query "needle compact" --k32 --bytes33554432` over the source fixture. Require exactly32fulloriginals/allfields/IDs, exact Search/Hit fields, finite bits, short nonnegative and31large negative, no continuation, exact rowIDs, validated semantic watermark and bounded fresh seal. Compare fullrecords to prior source-range oracle, require source closed inventory unchanged. CLI caps parsed output at32MiB; receipt stores only query/count/length/bound/recordhash/eligibility counts. No search payload log.
3. Keep strict nonempty exactly-one-item context matching the full short original and exact emitted context bytes across all eight arms. Preserve source/copy full32Record range checks, ciphertext inventories, complete CLI peak+whole-scope peak, all caps and outside identity cleanup.

Dispatcher is BYTE-IDENTICAL to reviewed attempt3. Worker changes only distinct paths, bounded preflight and its aggregate receipt; helper changes only query. See query-and-preflight.diff/planned-commands.json. AST parse only. Root reviews actual diff and independently dispatches at most once; no C execution or favorable rerun. This is a new predeclared scenario after baseline-only eligibility failure, not tuning after observing a candidate gain. No release/general/hosted speed or ordinary-context RAM claim.
