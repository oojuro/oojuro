#!/usr/bin/python3 -I
"""One complete real CLI invocation; hold scope alive for final peak readback."""
import hashlib,json,os,pathlib,resource,stat,subprocess,sys,time

def sha(p):
    with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def main():
    os.umask(0o077);assert len(sys.argv)==2
    fd=os.open(sys.argv[1],os.O_RDONLY|os.O_NOFOLLOW)
    with os.fdopen(fd,'rb') as f:
        meta=os.fstat(f.fileno());assert stat.S_ISREG(meta.st_mode) and meta.st_uid==os.getuid() and meta.st_nlink==1 and stat.S_IMODE(meta.st_mode)==0o600 and meta.st_size<8192;c=json.load(f)
    assert sha(c['binary'])==c['binary_sha256']
    assert resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss==0
    cmd=[c['binary'],'record-context','--root',c['root'],'--query','needle','--measure','chars4-estimate','--k','32','--top-k','1','--tokens','2500','--context-bytes','65536','--min-bits','0','--turn-start-us','9223372036854775807','--format','claude-hook','--bytes','65536']
    started=time.monotonic();child=None
    try:
        with open(c['stdout'],'xb') as out,open(c['stderr'],'xb') as err:
            child=subprocess.Popen(cmd,stdout=out,stderr=err);code=child.wait(timeout=100)
        wall=time.monotonic()-started;usage=resource.getrusage(resource.RUSAGE_CHILDREN)
        assert code==0 and pathlib.Path(c['stdout']).stat().st_size<=65536 and pathlib.Path(c['stderr']).stat().st_size<=65536
        r={'command':cmd,'exit':code,'cli_pid':child.pid,'wall_seconds':wall,'cli_max_rss_kib':usage.ru_maxrss,'cli_user_seconds':usage.ru_utime,'cli_system_seconds':usage.ru_stime,'stdout_sha256':sha(c['stdout']),'stdout_bytes':pathlib.Path(c['stdout']).stat().st_size,'helper_pid':os.getpid(),'helper_cgroup':pathlib.Path('/proc/self/cgroup').read_text().strip()}
        path=pathlib.Path(c['result']);tmp=path.with_name(path.name+'.pending');fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,'w') as f:json.dump(r,f);f.write('\n');f.flush();os.fsync(f.fileno())
        os.replace(tmp,path);deadline=time.monotonic()+10
        while not pathlib.Path(c['ack']).exists():assert time.monotonic()<deadline;time.sleep(.02)
        return 0
    finally:
        if child is not None and child.poll() is None:child.kill();child.wait(timeout=5)

if __name__=='__main__':raise SystemExit(main())
